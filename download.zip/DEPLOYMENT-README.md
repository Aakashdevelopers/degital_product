# NovaStore Digital Product Store — Final Production Deployment Guide

This guide details the exact procedure for deploying NovaStore on **ProFreeHost / vPanel Shared Hosting** at:
- **Website URL:** `https://mydigitalstore.unaux.com/index.html`
- **Admin Panel:** `https://mydigitalstore.unaux.com/admin/index.html`

> [!IMPORTANT]
> **DATABASE PRESERVATION:** The database schema is **already imported** on your hosting account (`ezyro_43263892_digital_store`). Do **NOT** reset, drop, truncate, recreate, or re-import `schema.sql` on the live database.

---

## 📁 1. Package Contents & Architecture

The deployment package `digital-store-production-final.zip` contains the complete, production-ready PHP/MySQL web application:

```
htdocs/ (Domain Document Root)
├── index.html                   # Storefront Homepage
├── product.html                 # SuperProfile Product Detail Page
├── my-purchases.html            # User Digital Product Library
├── login.html                   # Firebase Sign In / Sign Up Page
├── .htaccess                    # Apache Rewrite Rules & Security Config
├── config.example.php           # Safe Configuration Example Template
├── DEPLOYMENT-README.md         # Deployment Instructions
├── schema.sql                   # MySQL Database Schema Reference
├── admin/                       # Admin Control Panel
│   ├── index.html               # Overview Dashboard & Catalog Management
│   ├── add-product.html         # Add Product Form
│   ├── edit-product.html        # Edit Product Form
│   ├── categories.html          # Category Management
│   └── assets/                  # Admin Stylesheets & JS Modules
├── api/                         # RESTful Backend PHP Endpoints
│   ├── auth/                    # me.php, sync.php
│   ├── products/                # index.php, detail.php, categories.php
│   ├── purchases/               # demo-buy.php, my-purchases.php, download.php
│   ├── admin/                   # stats.php, products.php, product-detail.php, product-status.php, categories.php, category-detail.php, purchases.php
│   └── db-test.php              # Secure Diagnostic Endpoint (Admin Only)
├── config/                      # Core PHP Configuration & Security Middleware
│   ├── config.php               # Master Config & Private Credential Loader
│   ├── auth.php                 # Firebase Token Verification & RBAC Middleware
│   ├── db_config.example.php    # Example Private Config File Template
│   └── .htaccess                # Access Denied Policy for Config Folder
├── uploads/                     # Upload Storage
│   ├── public/                  # Product Cover Images (.htaccess Script Execution Blocked)
│   └── private/                 # Private Digital Download Files (.htaccess Direct Web Access Blocked)
└── assets/                      # Public CSS & JS Modules
    ├── css/
    └── js/
```

---

## 🗄️ 2. Step-by-Step Deployment Instructions

### Step 1: Upload Archive Files to `htdocs`
1. Log in to your ProFreeHost Account Control Panel (vPanel).
2. Open the **File Manager** or connect via FTP (FileZilla / WinSCP).
3. Navigate to your website's document root: `mydigitalstore.unaux.com/htdocs/` (or `htdocs/`).
4. Upload **`digital-store-production-final.zip`** and extract its contents directly into `htdocs/`.

### Step 2: Configure Database Credentials Privately

To ensure database credentials are never exposed publicly, choose one of the two supported private configuration methods:

#### Method A: Private File Outside `htdocs` (Recommended)
1. In File Manager, navigate one level up above `htdocs/` (into your root account directory).
2. Create a file named **`db_config.php`** (path: `/../db_config.php` relative to `htdocs`).
3. Add the following code and insert your actual vPanel MySQL password:
   ```php
   <?php
   define('DB_HOST', 'sql204.ezyro.com');
   define('DB_NAME', 'ezyro_43263892_digital_store');
   define('DB_USER', 'ezyro_43263892');
   define('DB_PASS', 'YOUR_ACTUAL_VPANEL_MYSQL_PASSWORD');
   ```

#### Method B: Local `config/db_config.php` File
If your host limits file creation outside `htdocs`:
1. In `htdocs/config/`, create a file named **`db_config.php`**.
2. Add the same configuration snippet as above.
3. Direct web access to `config/db_config.php` is strictly blocked by `config/.htaccess` and the main `.htaccess` `FilesMatch` rule.

#### How `config/config.php` Automatically Loads Your Credentials:
At runtime, [`config/config.php`](file:///C:/Users/aakas/AndroidStudioProjects/DoctorPoint/digital-store/config/config.php) executes:
```php
$outsideConfigFile = dirname(BASE_DIR) . '/db_config.php';
$localConfigFile   = BASE_DIR . '/config/db_config.php';

if (file_exists($outsideConfigFile) && is_readable($outsideConfigFile)) {
    require_once $outsideConfigFile;
} elseif (file_exists($localConfigFile) && is_readable($localConfigFile)) {
    require_once $localConfigFile;
}
```
If `DB_PASS` is not defined or left empty, database connection attempts fail safely without leaking error traces to visitors.

### Step 3: Verify HTTP Protection of Configuration Files
1. In a web browser, attempt to visit: `https://mydigitalstore.unaux.com/config/db_config.php`
2. Confirm the server returns a **403 Forbidden** error response.

---

## 🔒 3. Firebase Project & Administrator Account Verification

The existing Firebase project (`my-project-store-7047a`) configuration in [`assets/js/firebase-config.js`](file:///C:/Users/aakas/AndroidStudioProjects/DoctorPoint/digital-store/assets/js/firebase-config.js) is preserved.

### Designated Administrator Identity:
- **Admin Email:** `rohitmishra63072@gmail.com`
- **Admin Firebase UID:** `gdVsA2JoE2bgN1Cj458lJh9VcvN2`

When this account logs in at `https://mydigitalstore.unaux.com/login.html`, `api/auth/sync.php` cryptographically verifies the Firebase ID token with Google servers, matches the designated UID and email, and grants full administrator access.

---

## 🧪 4. Post-Deployment Verification Checklist

1. **Storefront Verification:** Visit `https://mydigitalstore.unaux.com/index.html` — Confirm catalog and hero section load cleanly.
2. **Admin Authentication:** Visit `https://mydigitalstore.unaux.com/admin/index.html` — Log in with `rohitmishra63072@gmail.com`. Confirm overview stats and product catalog load.
3. **Product Management:** Go to `admin/add-product.html` — Add a new digital product with cover banner image, private ZIP file, pricing, and features.
4. **Instant Purchase Grant:** Open the product on storefront, click **Get it now** — Confirm instant demo purchase grant.
5. **Private Download Security:** Go to **My Purchases** (`my-purchases.html`) — Confirm clicking **Download File** streams the file via `api/purchases/download.php`.
