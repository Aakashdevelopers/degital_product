# NovaStore Digital Storefront — InfinityFree Deployment Guide

This guide provides step-by-step instructions for deploying the digital storefront on **InfinityFree Shared Hosting** at:
- **User Store:** `https://mydigistore.site.je/`
- **Admin Panel:** `https://mydigistore.site.je/admin/`

---

## 📁 1. Directory Structure Overview & Upload Manifest

Upload the contents of `digital-store/` directly into your InfinityFree domain's document root (typically `htdocs` or `mydigistore.site.je/htdocs`).

```
htdocs/ (Domain Root: https://mydigistore.site.je/)
├── index.html                   # Storefront Homepage
├── product.html                 # SuperProfile Product Detail Page
├── my-purchases.html            # Customer Digital Library
├── login.html                   # Firebase Sign In / Sign Up Page
├── .htaccess                    # Apache Rewrite Rules & File Security
├── DEPLOYMENT.md                # Deployment Documentation
├── schema.sql                   # MySQL Relational Schema & Initial Seed
├── admin/                       # Admin Panel (https://mydigistore.site.je/admin/)
│   ├── index.html               # Admin Overview & Catalog Table
│   ├── add-product.html         # Add Product Form
│   ├── edit-product.html        # Edit Product Form
│   ├── categories.html          # Category Management Table
│   └── assets/                  # Admin CSS/JS
├── api/                         # Backend PHP Endpoints
│   ├── auth/                    # me.php, sync.php
│   ├── products/                # index.php, detail.php, categories.php
│   ├── purchases/               # demo-buy.php, my-purchases.php, download.php
│   ├── admin/                   # stats.php, products.php, product-detail.php, product-status.php, categories.php, category-detail.php, purchases.php
│   └── db-test.php              # Environment Diagnostic (Protected)
├── config/                      # PHP Configuration & Security
│   ├── config.php               # Database DSN & Environment Constants
│   └── auth.php                 # Firebase Token Verification & RBAC Middleware
├── uploads/                     # File Storage (Auto-created if missing)
│   ├── public/                  # Public Cover Banner Images
│   └── private/                 # Protected Digital Downloads (.htaccess protected)
└── assets/                      # Frontend CSS & ES6 JS Modules
    ├── css/
    └── js/
```

### 🚫 Files to EXCLUDE from Deployment:
Do **NOT** upload the following local development/Node files to InfinityFree:
- `server/` (Node.js/Express version - Not needed for PHP hosting)
- `client/` and `user/` (Legacy duplicate folders - Root files are authoritative)
- `*.bak` (Backup files)
- `.git/` or `.gitignore`

---

## 🗄️ 2. MySQL Database Setup on InfinityFree

1. Log into your **InfinityFree Control Panel**.
2. Go to **MySQL Databases** and create a new database.
3. Note down your MySQL connection parameters:
   - **MySQL Hostname:** (e.g. `sqlxxx.infinityfree.com`)
   - **MySQL Database Name:** (e.g. `if0_12345678_doctorpoint_store`)
   - **MySQL Username:** (e.g. `if0_12345678`)
   - **MySQL Password:** (Your InfinityFree account password)
   - **Port:** `3306`
4. Open **phpMyAdmin** for your new database.
5. Select your database and click **Import**.
6. Choose `schema.sql` from your local `digital-store/` folder and click **Go**.
7. Confirm that the following 5 tables were created:
   - `users`
   - `categories`
   - `products`
   - `purchases`
   - `admin_audit_logs`

---

## ⚙️ 3. Environment Configuration (`config/config.php`)

Open `config/config.php` on the server or locally before uploading, and update the environment constants with your InfinityFree database credentials:

```php
// Update DB credentials for InfinityFree
define('DB_HOST', 'sqlxxx.infinityfree.com'); // Your InfinityFree MySQL Host
define('DB_NAME', 'if0_12345678_doctorpoint_store'); // Your Database Name
define('DB_USER', 'if0_12345678');                  // Your Database User
define('DB_PASS', 'YOUR_INFINITYFREE_PASSWORD');     // Your Database Password
define('DB_PORT', '3306');
define('DB_CHARSET', 'utf8mb4');

// Firebase Project & Admin Email
define('FIREBASE_PROJECT_ID', 'my-project-store-7047a');
define('ADMIN_FIREBASE_UID', 'gdVsA2JoE2bgN1Cj458lJh9VcvN2');
define('ADMIN_FIREBASE_EMAIL', 'rohitmishra63072@gmail.com');
```

---

## 🔒 4. Security Verification

1. **Private Storage Protection:**  
   Confirm `uploads/private/.htaccess` contains:
   ```apache
   <IfModule mod_authz_core.c>
       Require all denied
   </IfModule>
   <IfModule !mod_authz_core.c>
       Order deny,allow
       Deny from all
   </IfModule>
   ```
   This prevents visitors from directly accessing `.zip`, `.pdf`, or digital download files via URL without going through authenticated purchase verification.

2. **HTTP Strict CORS & Error Handling:**  
   `display_errors` is disabled (`ini_set('display_errors', '0')`) in `config/config.php` to prevent SQL errors, stack traces, or credentials from leaking in API responses.

3. **Firebase Token Verification:**  
   Every API request to protected endpoints is cryptographically verified against Google Firebase TokenInfo / x509 public certificates. Fake dev tokens are unconditionally rejected on `mydigistore.site.je`.

---

## 🧪 5. Verification Checklist

After uploading files and configuring the database:

1. **Storefront Verification:**  
   Visit `https://mydigistore.site.je/`. Confirm hero banner, category pills, search bar, and footer load without errors.

2. **Admin Panel Access Verification:**  
   Visit `https://mydigistore.site.je/admin/`.  
   - Signing in with non-admin account must return `Access denied. Administrator privileges required.` and redirect to `../index.html`.  
   - Signing in with designated administrator (`rohitmishra63072@gmail.com` / `gdVsA2JoE2bgN1Cj458lJh9VcvN2`) loads the overview dashboard, stats, and product catalog.

3. **Product & Category CRUD:**  
   - Go to `https://mydigistore.site.je/admin/add-product.html`.  
   - Upload a cover image, set title, pricing, digital file, and SuperProfile features/testimonials/FAQs.  
   - Save product. Verify it appears on the public storefront.

4. **Instant Demo Purchase & Download Flow:**  
   - On the storefront, click **View Details** on a product card.  
   - Click **Get it now**. Confirm instant access is granted and "Demo Purchase — No Payment Processed" label appears.  
   - Go to **My Purchases** (`https://mydigistore.site.je/my-purchases.html`). Confirm the product appears in your library and clicking **Download File** initiates file stream download.
