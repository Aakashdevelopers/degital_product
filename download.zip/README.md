# MyDigitalStore — Direct Passwordless Purchase & Instant Checkout

A full-stack, responsive digital product storefront and management platform inspired by SuperProfile. Built with PHP, MySQL, JavaScript, and Firebase Authentication.

---

## ⚡ Direct Passwordless Checkout Flow

1. **Frictionless Purchase Experience**:
   - Product details, pricing, discount, subtotal, and total display directly on the product checkout page.
   - User inputs Email Address and Phone Number (with Country Code) directly on the product checkout card.
   - One-click **Get it now** button triggers server-side validation and access grant.
   - No forced password creation, no password prompt, and **no redirection to the login page**.

2. **Firebase Authentication Integration**:
   - Uses **Firebase Anonymous Authentication** (`signInAnonymously()`) when available to obtain a cryptographically verifiable Firebase ID Token.
   - Preserves existing Firebase project configuration (`my-project-store-7047a`), providers, and accounts.
   - Token claims (`uid`, `aud`, `iss`) are cryptographically verified server-side using Google's public key infrastructure.

3. **Safe Account Handling & Account Takeover Prevention**:
   - **New Email**: If the submitted email address does not exist in the database, a user account is automatically provisioned securely in MySQL without asking for a password.
   - **Existing Account**: If the submitted email address belongs to an existing account, the purchase is safely linked to that account in MySQL.
   - **Account Takeover Blocked**: The server **never** returns the existing user's profile object or session credentials to an unauthenticated/anonymous guest. The guest obtains instant product access *for the current purchase only*, while the existing account owner retains their full purchase history and security when logging in via Firebase.
   - **No Fake OTPs or Fabricated Credentials**: Real validation rules enforce valid email structures and phone number lengths (7+ digits) server-side.

4. **Server-Side Security & Price Authority**:
   - Product pricing, eligibility, and published status are strictly retrieved from trusted MySQL server-side data (`products` table).
   - Prepared SQL statements (`PDO`) prevent SQL injection across all queries.
   - Database compound unique constraints (`user_id` + `product_id`) prevent duplicate purchases from repeated button clicks or retries.
   - Digital product downloads (`/api/purchases/download.php`) enforce strict user ownership verification before streaming files.

---

## 🛠️ Firebase Console Configuration Required

To ensure seamless automatic authentication for guest users during passwordless checkout:

1. Open the [Firebase Console](https://console.firebase.google.com/).
2. Select project **my-project-store-7047a**.
3. Go to **Authentication** > **Sign-in method**.
4. Click on **Anonymous** under Additional Providers.
5. Toggle **Enable** to ON and click **Save**.

*Note: If Anonymous Authentication is not enabled, the application falls back gracefully to server-side guest user provisioning while preserving security.*

---

## 📁 Project Structure

```
digital-store/
├── index.html                   # Storefront Homepage
├── product.html                 # SuperProfile Product Detail & Passwordless Checkout
├── my-purchases.html            # User Digital Product Library
├── login.html                   # Firebase Sign In / Sign Up Page
├── .htaccess                    # Apache Rewrite Rules & Security Config
├── schema.sql                   # MySQL Database Schema Reference
├── README.md                    # Project Documentation
├── DEPLOYMENT-README.md         # Hosting Deployment Guide
├── TEST-REPORT.md               # Test Verification & Security Audit Report
├── admin/                       # Admin Control Panel
│   ├── index.html               # Overview Dashboard & Catalog Management
│   ├── add-product.html         # Add Product Form
│   ├── edit-product.html        # Edit Product Form
│   ├── categories.html          # Category Management
│   └── assets/                  # Admin Stylesheets & JS Modules
├── api/                         # RESTful Backend PHP Endpoints
│   ├── auth/                    # sync.php, me.php
│   ├── products/                # index.php, detail.php, categories.php
│   ├── purchases/               # demo-buy.php (Passwordless Endpoint), my-purchases.php, download.php
│   ├── admin/                   # stats.php, products.php, etc.
│   └── db-test.php              # Diagnostic Endpoint
├── config/                      # PHP Core Configuration & Security Middleware
│   ├── config.php               # Master Config & Credential Loader
│   ├── auth.php                 # Firebase Token Verification Middleware
│   └── .htaccess                # Access Denied Policy
├── uploads/                     # Upload Storage
│   ├── public/                  # Product Cover Banners
│   └── private/                 # Private Digital Product Files
└── assets/                      # Public CSS & JS Modules
    ├── css/                     # Custom Stylesheet
    └── js/                      # JS Controllers (product.js, auth.js, etc.)
```

---

## 🧪 Testing Checklist & Verification

- [x] **New User Passwordless Checkout**: Enter new email + phone -> Instant access granted, MySQL account provisioned without password prompt.
- [x] **Existing Account Handling**: Enter email of existing account -> Access granted for purchase without granting session takeover.
- [x] **Invalid Email / Phone Validation**: Client and server reject empty or malformed email/phone inputs.
- [x] **Duplicate Purchase Prevention**: Repeated clicks return existing grant without creating duplicate database rows.
- [x] **Server-Side Price Authority**: Client price inputs ignored; authoritative price fetched from MySQL.
- [x] **Authorized Downloads**: Streaming file downloads verify ownership in database.
- [x] **Firebase Token Verification**: Server cryptographically validates JWT tokens against Google OAuth2 tokeninfo / public certs.
