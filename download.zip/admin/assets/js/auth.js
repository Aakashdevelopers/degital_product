// Admin Panel Auth Manager with Live Firebase ID Token Support

const Auth = {
  async getToken(forceRefresh = false, quickCheck = false) {
    if (typeof firebase !== 'undefined' && firebase.auth) {
      let currentUser = firebase.auth().currentUser;

      if (!currentUser && !quickCheck) {
        await new Promise((resolve) => {
          let unsubscribe;
          const timer = setTimeout(() => {
            if (unsubscribe) unsubscribe();
            resolve(null);
          }, 1500);

          unsubscribe = firebase.auth().onAuthStateChanged((u) => {
            clearTimeout(timer);
            if (unsubscribe) unsubscribe();
            resolve(u);
          });
        });
        currentUser = firebase.auth().currentUser;
      }

      if (currentUser) {
        try {
          return await currentUser.getIdToken(forceRefresh);
        } catch (e) {
          console.warn('[Firebase Auth] ID token retrieval error:', e);
        }
      }
    }

    return null;
  },

  getUser() {
    const userJson = localStorage.getItem('novastore_user');
    return userJson ? JSON.parse(userJson) : null;
  },

  async login(email, password) {
    if (typeof firebase !== 'undefined' && firebase.auth) {
      try {
        const userCred = await firebase.auth().signInWithEmailAndPassword(email, password);
        const token = await userCred.user.getIdToken();

        const res = await fetch('/api/auth/sync', {
          method: 'POST',
          headers: {
            'Content-Type': 'application/json',
            'Authorization': `Bearer ${token}`,
            'X-Authorization': `Bearer ${token}`,
            'X-Bearer-Token': token
          },
          body: JSON.stringify({
            displayName: userCred.user.displayName || email.split('@')[0],
            accessToken: token
          })
        });
        const data = await res.json();

        if (data.success) {
          localStorage.setItem('novastore_user', JSON.stringify(data.data));
          return { success: true, user: data.data };
        } else {
          return { success: false, error: data.error || 'User synchronization failed' };
        }
      } catch (err) {
        console.warn('[Firebase Auth] Sign in error:', err.message);
        return { success: false, error: err.message || 'Firebase sign in failed' };
      }
    }

    return { success: false, error: 'Firebase Authentication SDK is not loaded' };
  },

  async resetPassword(email) {
    if (typeof firebase !== 'undefined' && firebase.auth) {
      try {
        await firebase.auth().sendPasswordResetEmail(email);
        return { success: true, message: 'Password reset link sent to your email address.' };
      } catch (err) {
        return { success: false, error: err.message || 'Failed to send password reset email.' };
      }
    }
    return { success: false, error: 'Firebase Authentication SDK is not loaded' };
  },

  async logout() {
    if (typeof firebase !== 'undefined' && firebase.auth) {
      try {
        await firebase.auth().signOut();
      } catch (e) {}
    }
    localStorage.removeItem('novastore_user');
    const isSubdir = window.location.pathname.includes('/admin/');
    const target = isSubdir ? '../login.html' : 'login.html';
    window.location.href = target;
  }
};
