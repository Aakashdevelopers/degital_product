<?php
/**
 * Database Connection & Environment Diagnostic Test Script
 * Endpoint: /api/db-test.php
 */

require_once __DIR__ . '/../config/auth.php';

// Diagnostic endpoint strictly restricted to authenticated administrators
$admin = requireAdmin();

try {
    $db = getDbConnection();

    // Query MySQL table counts
    $tables = ['users', 'categories', 'products', 'purchases', 'admin_audit_logs'];
    $tableCounts = [];

    foreach ($tables as $table) {
        try {
            $stmt = $db->query("SELECT COUNT(*) AS total FROM `" . $table . "`");
            $row = $stmt->fetch();
            $tableCounts[$table] = (int)$row['total'];
        } catch (Exception $e) {
            error_log('[DB Diagnostic] Table check error for ' . $table . ': ' . $e->getMessage());
            $tableCounts[$table] = 'Table not initialized';
        }
    }

    sendJsonResponse([
        'success'      => true,
        'message'      => 'MySQL Database connection verified.',
        'server_info'  => [
            'php_version'   => PHP_VERSION,
            'pdo_driver'    => $db->getAttribute(PDO::ATTR_DRIVER_NAME),
            'upload_public' => is_writable(UPLOAD_DIR_PUBLIC) ? 'Writable' : 'Not Writable',
            'upload_priv'   => is_writable(UPLOAD_DIR_PRIVATE) ? 'Writable' : 'Not Writable'
        ],
        'tables_found' => $tableCounts
    ]);
} catch (Exception $e) {
    error_log('[DB Diagnostic Fatal Error] ' . $e->getMessage());
    sendJsonResponse([
        'success' => false,
        'error'   => 'Database diagnostic failed. Please check server error log.'
    ], 500);
}
