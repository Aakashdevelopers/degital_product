<?php
/** Authoritative ZapUPI order status endpoint. */
require_once __DIR__ . '/../../config/zapupi_helpers.php';

if (!headers_sent()) {
    header('Content-Type: application/json; charset=utf-8');
    header('Cache-Control: no-store, no-cache, must-revalidate');
}

try {
    $raw = file_get_contents('php://input');
    $body = json_decode($raw ?: '', true);
    if (!is_array($body)) $body = [];
    $orderId = sanitizeString($_GET['order_id'] ?? $_POST['order_id'] ?? $body['order_id'] ?? '');
    if ($orderId === '') sendJsonResponse(['success'=>false, 'error'=>'Order ID parameter is required.'], 400);

    // The project's canonical connection function is getDbConnection().
    $db = getDbConnection();
    $sql = "SELECT po.*, prod.id AS prod_id, prod.title, prod.slug, prod.cover_image_path,
                   prod.file_size, prod.resource_url, prod.file_name, prod.private_file_path
            FROM payment_orders po
            INNER JOIN products prod ON po.product_id = prod.id
            WHERE po.order_id = :oid LIMIT 1";
    $stmt = $db->prepare($sql);
    $stmt->execute([':oid'=>$orderId]);
    $localOrder = $stmt->fetch(PDO::FETCH_ASSOC);
    if (!$localOrder) sendJsonResponse(['success'=>false, 'error'=>'Payment order not found.'], 404);

    if ($localOrder['status'] === 'pending') {
        $settled = zapupiSettleOrder($db, $localOrder);
        if ($settled === 'completed') $localOrder['status'] = 'completed';
        elseif ($settled === 'failed') $localOrder['status'] = 'failed';
        // Keep amount mismatches unfulfilled and visible as pending for manual reconciliation; never grant access on a mismatch.
    }

    // A pre-existing demo purchase must not turn an unpaid payment order into completed.
    $purStmt = $db->prepare("SELECT id FROM purchases WHERE user_id=:uid AND product_id=:pid AND purchase_type IN ('zapupi','paid') AND status='granted' LIMIT 1");
    $purStmt->execute([':uid'=>$localOrder['user_id'], ':pid'=>$localOrder['product_id']]);
    $purchaseRecord = $purStmt->fetch(PDO::FETCH_ASSOC);
    $isCompleted = ($localOrder['status'] === 'completed');

    $coverPath = !empty($localOrder['cover_image_path']) ? $localOrder['cover_image_path'] : 'default-cover.jpg';
    if (preg_match('~^https?://~i', $coverPath)) {
        $coverUrl = $coverPath;
    } else {
        $isHttps = (!empty($_SERVER['HTTPS']) && $_SERVER['HTTPS'] !== 'off') || (($_SERVER['HTTP_X_FORWARDED_PROTO'] ?? '') === 'https');
        $coverUrl = ($isHttps ? 'https' : 'http') . '://mydigitalstore.unaux.com/uploads/public/' . ltrim($coverPath, '/');
    }
    $fileSize = (int)($localOrder['file_size'] ?? 0);
    $fileSizeFormatted = $fileSize <= 0 ? 'Digital Download' : ($fileSize >= 1048576 ? number_format($fileSize / 1048576, 2) . ' MB' : number_format($fileSize / 1024, 2) . ' KB');

    sendJsonResponse(['success'=>true, 'data'=>[
        'orderId'=>$localOrder['order_id'],
        'status'=>$isCompleted ? 'completed' : $localOrder['status'],
        'amountINR'=>number_format(((int)$localOrder['amount_in_paise']) / 100, 2, '.', ''),
        'customerEmail'=>$localOrder['customer_email'],
        'createdAt'=>$localOrder['created_at'],
        'purchaseId'=>$purchaseRecord['id'] ?? null,
        'product'=>[
            'id'=>$localOrder['prod_id'], 'title'=>$localOrder['title'], 'slug'=>$localOrder['slug'],
            'coverImageUrl'=>$coverUrl, 'fileSizeFormatted'=>$fileSizeFormatted,
            'fileName'=>$localOrder['file_name'],
            'resourceUrl'=>$isCompleted ? ($localOrder['resource_url'] ?: null) : null
        ]
    ]]);
} catch (Throwable $e) {
    error_log('[Payment Status API] ' . get_class($e) . ': ' . $e->getMessage() . ' in ' . $e->getFile() . ':' . $e->getLine());
    sendJsonResponse(['success'=>false, 'error'=>'Unable to check payment status. Check the hosting PHP error log.'], 500);
}
