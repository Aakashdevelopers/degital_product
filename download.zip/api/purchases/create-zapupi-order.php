<?php
/**
 * Create ZapUPI Payment Order Endpoint
 * Endpoint: POST /api/purchases/create-zapupi-order
 */

require_once __DIR__ . '/../../config/auth.php';
require_once __DIR__ . '/../../config/zapupi_config.php';

// Optional authentication check (supports logged-in users and guest checkout)
$user = authenticateUser(false);

$rawInput = json_decode(file_get_contents('php://input'), true) ?: [];

$productId     = sanitizeString($_POST['productId'] ?? $_POST['product_id'] ?? $rawInput['productId'] ?? $rawInput['product_id'] ?? '');
$customerEmail = strtolower(sanitizeString($_POST['customerEmail'] ?? $_POST['customer_email'] ?? $_POST['email'] ?? $rawInput['customerEmail'] ?? $rawInput['customer_email'] ?? $rawInput['email'] ?? ($user['email'] ?? '')));
$phoneNumber   = sanitizeString($_POST['phoneNumber'] ?? $_POST['customer_mobile'] ?? $_POST['phone'] ?? $rawInput['phoneNumber'] ?? $rawInput['customer_mobile'] ?? $rawInput['phone'] ?? '');

if (empty($productId)) {
    sendJsonResponse(['success' => false, 'error' => 'Product ID parameter is required.'], 400);
}

if (empty($customerEmail) || !filter_var($customerEmail, FILTER_VALIDATE_EMAIL)) {
    sendJsonResponse(['success' => false, 'error' => 'Valid email address is required for checkout.'], 400);
}

$db = getDbConnection();

// Check or Auto-provision user account if guest
if (!$user) {
    $stmtEmail = $db->prepare("SELECT * FROM users WHERE LOWER(email) = LOWER(:email) LIMIT 1");
    $stmtEmail->execute([':email' => $customerEmail]);
    $user = $stmtEmail->fetch();

    if (!$user) {
        $adminEmail = defined('ADMIN_FIREBASE_EMAIL') ? strtolower(trim(ADMIN_FIREBASE_EMAIL)) : '';
        $isSoleAdmin = (!empty($adminEmail) && $customerEmail === $adminEmail);
        $targetRole = $isSoleAdmin ? 'admin' : 'user';

        $guestUid = 'guest_' . md5($customerEmail . time());
        $parts = explode('@', $customerEmail);
        $displayName = ucfirst($parts[0]);

        $insUserStmt = $db->prepare("
            INSERT INTO users (firebase_uid, email, display_name, role)
            VALUES (:uid, :email, :name, :role)
        ");
        $insUserStmt->execute([
            ':uid'   => $guestUid,
            ':email' => $customerEmail,
            ':name'  => $displayName,
            ':role'  => $targetRole
        ]);

        $newId = $db->lastInsertId();
        $user = [
            'id'           => $newId,
            'firebase_uid' => $guestUid,
            'email'        => $customerEmail,
            'display_name' => $displayName,
            'role'         => $targetRole
        ];
    }
}

$user['is_admin'] = ($user['role'] === 'admin');

// Fetch product details from DB
$prodStmt = $db->prepare("SELECT * FROM products WHERE id = :pid LIMIT 1");
$prodStmt->execute([':pid' => $productId]);
$product = $prodStmt->fetch();

if (!$product) {
    sendJsonResponse(['success' => false, 'error' => 'Product not found.'], 404);
}

if ($product['status'] !== 'published') {
    sendJsonResponse([
        'success' => false,
        'error'   => 'This product is unavailable or not currently published for purchase.'
    ], 400);
}

// Check if user already owns this product in MySQL
$purStmt = $db->prepare("SELECT * FROM purchases WHERE user_id = :uid AND product_id = :pid LIMIT 1");
$purStmt->execute([':uid' => $user['id'], ':pid' => $product['id']]);
$existingPurchase = $purStmt->fetch();

if ($existingPurchase) {
    sendJsonResponse([
        'success'      => true,
        'alreadyOwned' => true,
        'message'      => 'Product already present in your purchases library.',
        'data'         => [
            'purchaseId'   => $existingPurchase['id'],
            'purchaseType' => $existingPurchase['purchase_type'],
            'status'       => $existingPurchase['status'],
            'resourceUrl'  => $product['resource_url'] ?: 'https://drive.google.com/',
            'createdAt'    => $existingPurchase['created_at'],
            'user'         => [
                'id'          => $user['id'],
                'uid'         => $user['firebase_uid'],
                'email'       => $user['email'],
                'displayName' => $user['display_name'],
                'role'        => $user['role'],
                'isAdmin'     => $user['is_admin']
            ]
        ]
    ]);
}

$priceInPaise = (int)$product['price_in_paise'];

// Handle 0 paise free products directly
if ($priceInPaise <= 0) {
    try {
        $insStmt = $db->prepare("
            INSERT INTO purchases
            (user_id, firebase_uid, product_id, user_email, phone_number, purchase_type, status, price_snapshot_in_paise)
            VALUES
            (:user_id, :firebase_uid, :product_id, :email, :phone, 'demo', 'granted', 0)
            ON DUPLICATE KEY UPDATE status = 'granted'
        ");
        $insStmt->execute([
            ':user_id'      => $user['id'],
            ':firebase_uid' => $user['firebase_uid'],
            ':product_id'   => $product['id'],
            ':email'        => $customerEmail,
            ':phone'        => $phoneNumber
        ]);
    } catch (Exception $e) {}

    sendJsonResponse([
        'success'      => true,
        'alreadyOwned' => true,
        'message'      => 'Free product access granted to your library.',
        'data'         => [
            'resourceUrl' => $product['resource_url'] ?: 'https://drive.google.com/'
        ]
    ]);
}

$apiKey = getZapupiApiKey();
if ($apiKey === '') {
    error_log('[ZapUPI] API key missing or placeholder in config/zapupi_config.php');
    sendJsonResponse([
        'success' => false,
        'error'   => 'Payment gateway is not configured. Please contact support.'
    ], 500);
}

// Unique, unguessable order id (also acts as the access key for the payment-status page)
$orderId   = 'ORD_' . time() . '_' . bin2hex(random_bytes(8));
$amountINR = number_format($priceInPaise / 100, 2, '.', '');

$baseUrl     = zapupiSiteBaseUrl();
// No query string here: ZapUPI appends ?order_id=...&utr=... itself
$returnUrl   = $baseUrl . '/payment-status.html';
$webhookUrl  = $baseUrl . '/api/purchases/zapupi-webhook.php';

$cleanPhone = !empty($phoneNumber) ? preg_replace('/[^0-9]/', '', $phoneNumber) : '';
if (strlen($cleanPhone) > 10) {
    $cleanPhone = substr($cleanPhone, -10); // drop country code (+91...)
}
if (strlen($cleanPhone) < 10) {
    $cleanPhone = '9876543210';
}

// Store local order BEFORE calling the gateway
try {
    $insOrderStmt = $db->prepare("
        INSERT INTO payment_orders
        (order_id, user_id, firebase_uid, product_id, customer_email, customer_phone, amount_in_paise, status)
        VALUES
        (:order_id, :user_id, :firebase_uid, :product_id, :email, :phone, :amount, 'pending')
    ");
    $insOrderStmt->execute([
        ':order_id'     => $orderId,
        ':user_id'      => $user['id'],
        ':firebase_uid' => $user['firebase_uid'],
        ':product_id'   => $product['id'],
        ':email'        => $customerEmail,
        ':phone'        => $phoneNumber,
        ':amount'       => $priceInPaise
    ]);
} catch (PDOException $e) {
    error_log('[Database Error] Failed to create local payment order: ' . $e->getMessage());
    sendJsonResponse([
        'success' => false,
        'error'   => 'Could not initialize order. Did you run migration_zapupi.sql?'
    ], 500);
}

// ZapUPI may reject remarks containing separators, order IDs, plus signs,
// or long product titles. Send a short, plain-ASCII description only.
// Keep order_id in its dedicated field; do not duplicate it inside remark.
$rawTitle = (string)($product['title'] ?? '');
$asciiTitle = preg_replace('/[^A-Za-z0-9 ]+/', ' ', $rawTitle);
$asciiTitle = preg_replace('/\s+/', ' ', trim((string)$asciiTitle));
if ($asciiTitle === '') {
    $asciiTitle = 'Digital Product';
}
$safeTitle = function_exists('mb_substr')
    ? mb_substr($asciiTitle, 0, 24, 'UTF-8')
    : substr($asciiTitle, 0, 24);
$remark = trim($safeTitle);
if ($remark === '') {
    $remark = 'Digital Product';
}

$res = zapupiPost(ZAPUPI_CREATE_ORDER_ENDPOINT, [
    'zap_key'         => $apiKey,
    'order_id'        => $orderId,
    'amount'          => $amountINR,
    'customer_mobile' => $cleanPhone,
    'remark'          => $remark,
    'webhook_url'     => $webhookUrl,
    'success_url'     => $returnUrl,
    'failed_url'      => $returnUrl,
    'timeout_url'     => $returnUrl,
]);

$markFailed = function (string $raw) use ($db, $orderId) {
    $upd = $db->prepare("UPDATE payment_orders SET status = 'failed', raw_response = :raw WHERE order_id = :oid");
    $upd->execute([':raw' => substr($raw, 0, 2000), ':oid' => $orderId]);
};

if (!$res['ok']) {
    error_log('[ZapUPI] create-order failed: ' . ($res['error'] ?: ('HTTP ' . $res['http'] . ' ' . substr($res['raw'], 0, 200))));
    $markFailed($res['raw'] ?: $res['error']);
    sendJsonResponse([
        'success' => false,
        'error'   => 'Could not reach the payment gateway. Please try again in a moment.'
    ], 502);
}

$zapData    = $res['data'];
$paymentUrl = $zapData['payment_url'] ?? $zapData['data']['payment_url'] ?? $zapData['url'] ?? $zapData['data']['url'] ?? '';
$isSuccess  = isset($zapData['status']) && strtolower((string)$zapData['status']) === 'success' && $paymentUrl !== '';

if (!$isSuccess) {
    $errMsg = $zapData['message'] ?? $zapData['error'] ?? 'Gateway rejected the order.';
    error_log("[ZapUPI] Order {$orderId} rejected: " . $res['raw']);
    $markFailed($res['raw']);
    sendJsonResponse(['success' => false, 'error' => (string)$errMsg], 400);
}

$updOrder = $db->prepare("UPDATE payment_orders SET payment_url = :purl, raw_response = :raw WHERE order_id = :oid");
$updOrder->execute([':purl' => $paymentUrl, ':raw' => substr($res['raw'], 0, 2000), ':oid' => $orderId]);

sendJsonResponse([
    'success'     => true,
    'status'      => 'success',
    'order_id'    => $orderId,
    'payment_url' => $paymentUrl,
    'message'     => 'Order created. Redirecting to ZapUPI payment page...'
]);
