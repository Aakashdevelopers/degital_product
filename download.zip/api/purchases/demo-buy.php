<?php
/**
 * Instant Purchase & Passwordless Auto-Account Grant Endpoint
 * Endpoint: POST /api/purchases/demo-buy
 */

require_once __DIR__ . '/../../config/auth.php';

// Optional authentication check (supports logged-in users, anonymous Firebase users, and guest users)
$user = authenticateUser(false);

$rawInput = json_decode(file_get_contents('php://input'), true) ?: [];

$productId     = sanitizeString($_POST['productId'] ?? $rawInput['productId'] ?? '');
$customerEmail = strtolower(trim(sanitizeString($_POST['customerEmail'] ?? $rawInput['customerEmail'] ?? ($user['email'] ?? ''))));
$phoneNumber   = sanitizeString($_POST['phoneNumber'] ?? $rawInput['phoneNumber'] ?? '');

if (empty($productId)) {
    sendJsonResponse(['success' => false, 'error' => 'Product ID parameter is required.'], 400);
}

if (empty($customerEmail) || !filter_var($customerEmail, FILTER_VALIDATE_EMAIL)) {
    sendJsonResponse(['success' => false, 'error' => 'Valid email address is required.'], 400);
}

// Phone number validation: must not be empty and must contain at least 7 digits
$digitsOnly = preg_replace('/\D/', '', $phoneNumber);
if (empty($phoneNumber) || strlen($digitsOnly) < 7) {
    sendJsonResponse(['success' => false, 'error' => 'Valid phone number is required (at least 7 digits).'], 400);
}

$db = getDbConnection();

// Fetch product details from DB first (Authoritative price and status check)
$prodStmt = $db->prepare("SELECT * FROM products WHERE id = :pid LIMIT 1");
$prodStmt->execute([':pid' => $productId]);
$product = $prodStmt->fetch();

if (!$product) {
    sendJsonResponse(['success' => false, 'error' => 'Product not found.'], 404);
}

if ($product['status'] !== 'published') {
    sendJsonResponse([
        'success' => false,
        'error'   => 'This product is unavailable or not currently published for purchase.'
    ], 400);
}

// Strict Security Enforcement: Paid products MUST NOT bypass payment gateway via demo-buy
if ((int)$product['price_in_paise'] > 0) {
    sendJsonResponse([
        'success' => false,
        'error'   => 'Paid products require verified payment via ZapUPI payment gateway. Direct access grant forbidden.'
    ], 403);
}

// 1. Check if a database user record ALREADY exists matching the submitted email
$stmtEmail = $db->prepare("SELECT * FROM users WHERE LOWER(email) = LOWER(:email) LIMIT 1");
$stmtEmail->execute([':email' => $customerEmail]);
$existingUserByEmail = $stmtEmail->fetch();

$targetUser = null;
$returnUserPayload = null;

if ($existingUserByEmail) {
    // Account exists for this email!
    $targetUser = $existingUserByEmail;

    if ($user && (int)$user['id'] === (int)$existingUserByEmail['id']) {
        $user['is_admin'] = ($user['role'] === 'admin');
        $returnUserPayload = [
            'id'          => $user['id'],
            'uid'         => $user['firebase_uid'],
            'email'       => $user['email'],
            'displayName' => $user['display_name'],
            'role'        => $user['role'],
            'isAdmin'     => $user['is_admin']
        ];
    } else {
        $returnUserPayload = null;
    }
} else {
    if ($user) {
        $targetUser = $user;

        if (empty($user['email']) || strpos($user['email'], '@store.local') !== false) {
            $updStmt = $db->prepare("UPDATE users SET email = :email WHERE id = :id");
            $updStmt->execute([':email' => $customerEmail, ':id' => $user['id']]);
            $targetUser['email'] = $customerEmail;
        }

        $targetUser['is_admin'] = ($targetUser['role'] === 'admin');
        $returnUserPayload = [
            'id'          => $targetUser['id'],
            'uid'         => $targetUser['firebase_uid'],
            'email'       => $customerEmail,
            'displayName' => $targetUser['display_name'],
            'role'        => $targetUser['role'],
            'isAdmin'     => $targetUser['is_admin']
        ];
    } else {
        $adminEmail = defined('ADMIN_FIREBASE_EMAIL') ? strtolower(trim(ADMIN_FIREBASE_EMAIL)) : '';
        $isSoleAdmin = (!empty($adminEmail) && $customerEmail === $adminEmail);
        $targetRole = $isSoleAdmin ? 'admin' : 'user';

        $guestUid = 'guest_' . bin2hex(random_bytes(16));
        $parts = explode('@', $customerEmail);
        $displayName = ucfirst($parts[0]);

        $insUserStmt = $db->prepare("
            INSERT INTO users (firebase_uid, email, display_name, role)
            VALUES (:uid, :email, :name, :role)
        ");
        $insUserStmt->execute([
            ':uid'   => $guestUid,
            ':email' => $customerEmail,
            ':name'  => $displayName,
            ':role'  => $targetRole
        ]);

        $newId = $db->lastInsertId();
        $targetUser = [
            'id'           => $newId,
            'firebase_uid' => $guestUid,
            'email'        => $customerEmail,
            'display_name' => $displayName,
            'role'         => $targetRole,
            'is_admin'     => ($targetRole === 'admin')
        ];

        $returnUserPayload = [
            'id'          => $targetUser['id'],
            'uid'         => $targetUser['firebase_uid'],
            'email'       => $customerEmail,
            'displayName' => $targetUser['display_name'],
            'role'        => $targetUser['role'],
            'isAdmin'     => $targetUser['is_admin']
        ];
    }
}

// Check if purchase already exists for target user and product
$purStmt = $db->prepare("SELECT * FROM purchases WHERE user_id = :uid AND product_id = :pid LIMIT 1");
$purStmt->execute([':uid' => $targetUser['id'], ':pid' => $product['id']]);
$existingPurchase = $purStmt->fetch();

if ($existingPurchase) {
    sendJsonResponse([
        'success'      => true,
        'alreadyOwned' => true,
        'message'      => 'Product already present in your purchases library.',
        'data'         => [
            'purchaseId'   => $existingPurchase['id'],
            'purchaseType' => $existingPurchase['purchase_type'],
            'status'       => $existingPurchase['status'],
            'resourceUrl'  => $product['resource_url'] ?: 'https://drive.google.com/',
            'createdAt'    => $existingPurchase['created_at'],
            'user'         => $returnUserPayload
        ]
    ]);
}

// Create new purchase access grant in MySQL ONLY for 0 paise products
try {
    $insStmt = $db->prepare("
        INSERT INTO purchases
        (user_id, firebase_uid, product_id, user_email, phone_number, purchase_type, status, price_snapshot_in_paise)
        VALUES
        (:user_id, :firebase_uid, :product_id, :user_email, :phone_number, 'demo', 'granted', :price)
    ");

    $insStmt->execute([
        ':user_id'      => $targetUser['id'],
        ':firebase_uid' => $targetUser['firebase_uid'],
        ':product_id'   => $product['id'],
        ':user_email'   => $customerEmail,
        ':phone_number' => $phoneNumber,
        ':price'        => $product['price_in_paise']
    ]);

    $purchaseId = $db->lastInsertId();

    sendJsonResponse([
        'success'      => true,
        'alreadyOwned' => false,
        'message'      => 'Free product access granted successfully!',
        'data'         => [
            'purchaseId'   => $purchaseId,
            'productId'    => $product['id'],
            'productTitle' => $product['title'],
            'resourceUrl'  => $product['resource_url'] ?: 'https://drive.google.com/',
            'purchaseType' => 'demo',
            'status'       => 'granted',
            'createdAt'    => date('Y-m-d H:i:s'),
            'user'         => $returnUserPayload
        ]
    ], 201);
} catch (PDOException $e) {
    if ($e->getCode() == 23000 || strpos($e->getMessage(), '1062') !== false) {
        $purStmt->execute([':uid' => $targetUser['id'], ':pid' => $product['id']]);
        $existing = $purStmt->fetch();

        sendJsonResponse([
            'success'      => true,
            'alreadyOwned' => true,
            'message'      => 'Product already present in your purchases library.',
            'data'         => [
                'purchaseId'   => $existing['id'] ?? null,
                'purchaseType' => 'demo',
                'status'       => 'granted',
                'resourceUrl'  => $product['resource_url'] ?: 'https://drive.google.com/',
                'user'         => $returnUserPayload
            ]
        ]);
    }

    sendJsonResponse(['success' => false, 'error' => 'An error occurred while granting purchase access.'], 500);
}
