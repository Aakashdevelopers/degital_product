<?php
/**
 * Authorized Private File Download Endpoint
 * Endpoint: GET /api/purchases/download.php?id={purchaseId}
 */

require_once __DIR__ . '/../../config/auth.php';

$user = authenticateUser(true);

$purchaseId = sanitizeString($_GET['id'] ?? '');

if (empty($purchaseId)) {
    sendJsonResponse(['success' => false, 'error' => 'Purchase ID parameter is required.'], 400);
}

$db = getDbConnection();

$sql = "SELECT pur.*, prod.title, prod.category, prod.private_file_path, prod.file_name, prod.resource_url
        FROM purchases pur
        INNER JOIN products prod ON pur.product_id = prod.id
        WHERE pur.id = :id LIMIT 1";

$stmt = $db->prepare($sql);
$stmt->execute([':id' => $purchaseId]);
$purchase = $stmt->fetch();

if (!$purchase) {
    sendJsonResponse(['success' => false, 'error' => 'Purchase record not found.'], 404);
}

// Strict Ownership Verification
if ((int)$purchase['user_id'] !== (int)$user['id'] && !$user['is_admin']) {
    sendJsonResponse([
        'success' => false,
        'error'   => 'Forbidden. You do not have permission to download this digital file.'
    ], 403);
}

$fileName = $purchase['file_name'] ?: 'digital-product.zip';
$privateFilePath = UPLOAD_DIR_PRIVATE . ltrim($purchase['private_file_path'], '/');

// Strict Canonical Directory Boundary Check
$realPrivateDir = realpath(UPLOAD_DIR_PRIVATE);
$realFilePath   = realpath($privateFilePath);

if ($realPrivateDir !== false && $realFilePath !== false) {
    $privatePrefix = rtrim($realPrivateDir, '/\\') . DIRECTORY_SEPARATOR;

    if (
        !empty($purchase['private_file_path']) &&
        strpos($realFilePath, $privatePrefix) === 0 &&
        is_file($realFilePath)
    ) {
        // Clear any active output buffers
        if (ob_get_level()) {
            ob_end_clean();
        }

        header('Content-Description: File Transfer');
        header('Content-Type: application/octet-stream');
        header('Content-Disposition: attachment; filename="' . preg_replace('/[^a-zA-Z0-9_\-\.]/', '_', basename($fileName)) . '"');
        header('Content-Length: ' . filesize($realFilePath));
        header('Expires: 0');
        header('Cache-Control: must-revalidate, post-check=0, pre-check=0');
        header('Pragma: public');

        readfile($realFilePath);
        exit;
    }
}

// File does not exist on disk — Return clear error response
sendJsonResponse([
    'success' => false,
    'error'   => 'Digital product file is currently missing or unavailable on server. Please contact support.'
], 404);
