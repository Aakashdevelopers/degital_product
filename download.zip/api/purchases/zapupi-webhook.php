<?php
/**
 * ZapUPI Payment Gateway Webhook Receiver
 * Endpoint: POST /api/purchases/zapupi-webhook.php  (also /api/purchases/zapupi-webhook)
 *
 * Security: the webhook body is only a hint. Access is granted only after the
 * server independently confirms the payment through ZapUPI's order-status API.
 * Always answers HTTP 200 {"status":"ok"} so ZapUPI does not keep retrying.
 */

require_once __DIR__ . '/../../config/zapupi_helpers.php';

function acknowledgeWebhook(array $data = ['status' => 'ok']) {
    if (!headers_sent()) {
        http_response_code(200);
        header('Content-Type: application/json; charset=utf-8');
    }
    echo json_encode($data);
    exit;
}

// Browser diagnostic: open this URL in a browser to confirm it is reachable
if ($_SERVER['REQUEST_METHOD'] === 'GET') {
    acknowledgeWebhook(['status' => 'ok', 'message' => 'ZapUPI webhook endpoint active. Expects HTTP POST.']);
}
if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    acknowledgeWebhook(['status' => 'error', 'message' => 'Use HTTP POST.']);
}

$rawInput    = file_get_contents('php://input');
$webhookData = json_decode($rawInput, true);
if (!is_array($webhookData)) {
    $webhookData = $_POST ?: [];
}

$orderId = sanitizeString($webhookData['order_id'] ?? $webhookData['orderId'] ?? '');
if ($orderId === '') {
    error_log('[ZapUPI Webhook] Received without order_id.');
    acknowledgeWebhook(['status' => 'ok', 'message' => 'Missing order_id ignored']);
}

$db   = getDbConnection();
$stmt = $db->prepare("SELECT * FROM payment_orders WHERE order_id = :oid LIMIT 1");
$stmt->execute([':oid' => $orderId]);
$localOrder = $stmt->fetch();

if (!$localOrder) {
    error_log("[ZapUPI Webhook] Unknown order {$orderId}.");
    acknowledgeWebhook(['status' => 'ok', 'message' => 'Order not found']);
}

$result = zapupiSettleOrder($db, $localOrder);   // idempotent: already-completed orders return immediately
acknowledgeWebhook(['status' => 'ok', 'message' => 'Order ' . $result]);
