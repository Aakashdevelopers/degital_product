// User Panel Auth Manager with Live Firebase ID Token Support

const Auth = {
  // Returns fresh Firebase ID token
  async getToken(forceRefresh = false, quickCheck = false) {
    if (typeof firebase !== 'undefined' && firebase.auth) {
      let currentUser = firebase.auth().currentUser;

      if (!currentUser && !quickCheck) {
        await new Promise((resolve) => {
          let unsubscribe;
          const timer = setTimeout(() => {
            if (unsubscribe) unsubscribe();
            resolve(null);
          }, 1000);

          unsubscribe = firebase.auth().onAuthStateChanged((u) => {
            clearTimeout(timer);
            if (unsubscribe) unsubscribe();
            resolve(u);
          });
        });
        currentUser = firebase.auth().currentUser;
      }

      if (currentUser) {
        try {
          return await currentUser.getIdToken(forceRefresh);
        } catch (e) {
          console.warn('[Firebase Auth] ID token retrieval error:', e);
        }
      }
    }

    return null;
  },

  getUser() {
    const userJson = localStorage.getItem('novastore_user');
    return userJson ? JSON.parse(userJson) : null;
  },

  async login(email, password) {
    if (typeof firebase !== 'undefined' && firebase.auth) {
      try {
        const userCred = await firebase.auth().signInWithEmailAndPassword(email, password);
        const token = await userCred.user.getIdToken();

        const res = await fetch('/api/auth/sync', {
          method: 'POST',
          headers: {
            'Content-Type': 'application/json',
            'Authorization': `Bearer ${token}`,
            'X-Authorization': `Bearer ${token}`,
            'X-Bearer-Token': token
          },
          body: JSON.stringify({
            displayName: userCred.user.displayName || email.split('@')[0],
            accessToken: token
          })
        });
        const data = await res.json();

        if (data.success) {
          localStorage.setItem('novastore_user', JSON.stringify(data.data));
          return { success: true, user: data.data };
        } else {
          return { success: false, error: data.error || 'User synchronization failed' };
        }
      } catch (err) {
        console.warn('[Firebase Auth] Sign in error:', err.message);
        return { success: false, error: err.message || 'Firebase sign in failed' };
      }
    }

    return { success: false, error: 'Firebase Authentication SDK is not loaded' };
  },

  async register(email, password, displayName) {
    if (typeof firebase !== 'undefined' && firebase.auth) {
      try {
        const userCred = await firebase.auth().createUserWithEmailAndPassword(email, password);
        if (displayName) {
          await userCred.user.updateProfile({ displayName });
        }
        const token = await userCred.user.getIdToken();

        const res = await fetch('/api/auth/sync', {
          method: 'POST',
          headers: {
            'Content-Type': 'application/json',
            'Authorization': `Bearer ${token}`,
            'X-Authorization': `Bearer ${token}`,
            'X-Bearer-Token': token
          },
          body: JSON.stringify({
            displayName: displayName || email.split('@')[0],
            accessToken: token
          })
        });
        const data = await res.json();
        if (data.success) {
          localStorage.setItem('novastore_user', JSON.stringify(data.data));
          return { success: true, user: data.data };
        } else {
          return { success: false, error: data.error || 'User creation sync failed' };
        }
      } catch (err) {
        console.warn('[Firebase Auth] Register error:', err.message);
        return { success: false, error: err.message || 'Firebase registration failed' };
      }
    }

    return { success: false, error: 'Firebase Authentication SDK is not loaded' };
  },

  async resetPassword(email) {
    if (typeof firebase !== 'undefined' && firebase.auth) {
      try {
        await firebase.auth().sendPasswordResetEmail(email);
        return { success: true, message: 'Password reset link sent to your email address.' };
      } catch (err) {
        return { success: false, error: err.message || 'Failed to send password reset email.' };
      }
    }
    return { success: false, error: 'Firebase Authentication SDK is not loaded' };
  },

  async logout() {
    if (typeof firebase !== 'undefined' && firebase.auth) {
      try {
        await firebase.auth().signOut();
      } catch (e) {}
    }
    localStorage.removeItem('novastore_user');
    const isSubdir = window.location.pathname.includes('/admin/');
    const target = isSubdir ? '../login.html' : 'login.html';
    window.location.href = target;
  },

  updateNavUI() {
    const user = this.getUser();
    const navLinksContainer = document.getElementById('nav-links-dynamic');
    if (!navLinksContainer) return;

    const isSubdir = window.location.pathname.includes('/admin/');
    const homePath = isSubdir ? '../index.html' : 'index.html';
    const myPurchasesPath = isSubdir ? '../my-purchases.html' : 'my-purchases.html';
    const adminPath = isSubdir ? 'index.html' : 'admin/index.html';
    const loginPath = isSubdir ? '../login.html' : 'login.html';

    if (user) {
      navLinksContainer.innerHTML = `
        <a href="${homePath}" class="nav-link">Store</a>
        <a href="${myPurchasesPath}" class="nav-link">My Purchases</a>
        ${user.isAdmin ? `<a href="${adminPath}" class="nav-link" style="color:#6366f1;font-weight:700;">Admin Panel</a>` : ''}
        <span style="font-size:0.88rem;color:var(--text-muted);margin-left:0.5rem;">Hi, <strong>${user.displayName || user.email.split('@')[0]}</strong></span>
        <button onclick="Auth.logout()" class="btn btn-outline" style="padding:0.4rem 0.9rem;font-size:0.85rem;">Logout</button>
      `;
    } else {
      navLinksContainer.innerHTML = `
        <a href="${homePath}" class="nav-link">Store</a>
        <a href="${loginPath}" class="btn btn-outline" style="padding:0.4rem 1rem;">Sign In</a>
        <a href="${loginPath}?mode=signup" class="btn btn-primary" style="padding:0.4rem 1rem;">Sign Up</a>
      `;
    }
  }
};

// Initialize Firebase Auth State Listener
document.addEventListener('DOMContentLoaded', () => {
  Auth.updateNavUI();

  if (typeof firebase !== 'undefined' && firebase.auth) {
    firebase.auth().onAuthStateChanged(async (fbUser) => {
      if (fbUser) {
        try {
          const token = await fbUser.getIdToken();
          const res = await fetch('/api/auth/sync', {
            method: 'POST',
            headers: {
              'Content-Type': 'application/json',
              'Authorization': `Bearer ${token}`,
              'X-Authorization': `Bearer ${token}`,
              'X-Bearer-Token': token
            },
            body: JSON.stringify({
              displayName: fbUser.displayName || fbUser.email.split('@')[0],
              accessToken: token
            })
          });
          const data = await res.json();
          if (data.success) {
            localStorage.setItem('novastore_user', JSON.stringify(data.data));
            Auth.updateNavUI();
          }
        } catch (e) {
          console.warn('[Firebase Auth Listener] Sync warning:', e);
        }
      } else {
        localStorage.removeItem('novastore_user');
        Auth.updateNavUI();
      }
    });
  }
});
