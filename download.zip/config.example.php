<?php
/**
 * NovaStore Digital Storefront - Configuration Template
 * Copy this file to config/config.php and update with your actual database parameters.
 */

// Immediate CORS Preflight Handling
if (isset($_SERVER['REQUEST_METHOD']) && $_SERVER['REQUEST_METHOD'] === 'OPTIONS') {
    http_response_code(200);
    header('Access-Control-Allow-Origin: *');
    header('Access-Control-Allow-Methods: GET, POST, PUT, PATCH, DELETE, OPTIONS');
    header('Access-Control-Allow-Headers: Content-Type, Authorization, X-Requested-With');
    header('Access-Control-Max-Age: 86400');
    exit(0);
}

// Disable error display in output to protect server credentials
error_reporting(E_ALL);
ini_set('display_errors', '0');
ini_set('log_errors', '1');

// Base Paths
define('BASE_DIR', __DIR__);
define('UPLOAD_DIR_PUBLIC', BASE_DIR . '/uploads/public/');
define('UPLOAD_DIR_PRIVATE', BASE_DIR . '/uploads/private/');

// Ensure Upload Directories Exist
if (!file_exists(UPLOAD_DIR_PUBLIC)) {
    @mkdir(UPLOAD_DIR_PUBLIC, 0755, true);
}
if (!file_exists(UPLOAD_DIR_PRIVATE)) {
    @mkdir(UPLOAD_DIR_PRIVATE, 0755, true);
    @file_put_contents(UPLOAD_DIR_PRIVATE . '.htaccess', "<IfModule mod_authz_core.c>\n    Require all denied\n</IfModule>\n<IfModule !mod_authz_core.c>\n    Order deny,allow\n    Deny from all\n</IfModule>");
}

// MySQL Database Parameters (Replace with your hosting control panel values)
define('DB_HOST', 'sql204.ezyro.com');                  // MySQL Hostname
define('DB_NAME', 'ezyro_43263892_digital_store');      // Database Name
define('DB_USER', 'ezyro_43263892');                    // Database Username
define('DB_PASS', 'YOUR_VPANEL_MYSQL_PASSWORD');        // Database Password (vPanel / Hosting Password)
define('DB_PORT', '3306');                             // Port
define('DB_CHARSET', 'utf8mb4');                       // Charset

// Firebase Authentication Parameters
define('FIREBASE_PROJECT_ID', 'my-project-store-7047a');

// Designated Sole Administrator Firebase Identity
define('ADMIN_FIREBASE_UID', 'gdVsA2JoE2bgN1Cj458lJh9VcvN2');
define('ADMIN_FIREBASE_EMAIL', 'rohitmishra63072@gmail.com');

// Dev Token Bypass (Disabled on production)
define('ALLOW_DEV_TOKENS', false);
