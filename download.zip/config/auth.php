<?php
/**
 * Server-Side Firebase ID Token Verification & RBAC Middleware
 * Designed for PHP 7.4+ / 8.x and Shared Hosting
 */

require_once __DIR__ . '/config.php';

/**
 * Extracts Authorization Bearer Token from HTTP Request Headers
 *
 * @return string|null
 */
function getBearerToken(): ?string {
    $headers = null;

    if (!empty($_SERVER['HTTP_AUTHORIZATION'])) {
        $headers = trim($_SERVER['HTTP_AUTHORIZATION']);
    } elseif (!empty($_SERVER['REDIRECT_HTTP_AUTHORIZATION'])) {
        $headers = trim($_SERVER['REDIRECT_HTTP_AUTHORIZATION']);
    } elseif (!empty($_SERVER['HTTP_X_AUTHORIZATION'])) {
        $headers = trim($_SERVER['HTTP_X_AUTHORIZATION']);
    } elseif (!empty($_SERVER['HTTP_X_BEARER_TOKEN'])) {
        return trim($_SERVER['HTTP_X_BEARER_TOKEN']);
    } elseif (function_exists('apache_request_headers')) {
        $requestHeaders = apache_request_headers();
        if (is_array($requestHeaders)) {
            $requestHeaders = array_combine(
                array_map('ucwords', array_keys($requestHeaders)),
                array_values($requestHeaders)
            );
            if (!empty($requestHeaders['Authorization'])) {
                $headers = trim($requestHeaders['Authorization']);
            } elseif (!empty($requestHeaders['X-Authorization'])) {
                $headers = trim($requestHeaders['X-Authorization']);
            } elseif (!empty($requestHeaders['X-Bearer-Token'])) {
                return trim($requestHeaders['X-Bearer-Token']);
            }
        }
    }

    if (!empty($headers)) {
        if (preg_match('/Bearer\s(\S+)/i', $headers, $matches)) {
            return $matches[1];
        }
        return $headers;
    }

    // Fallback Query String / POST Body Checks
    if (!empty($_GET['access_token'])) {
        return trim($_GET['access_token']);
    }
    if (!empty($_POST['access_token'])) {
        return trim($_POST['access_token']);
    }

    $rawInput = @json_decode(file_get_contents('php://input'), true);
    if (is_array($rawInput) && !empty($rawInput['accessToken'])) {
        return trim($rawInput['accessToken']);
    }

    return null;
}

/**
 * Helper to decode Base64Url strings safely
 *
 * @param string $input
 * @return string
 */
function base64UrlDecode(string $input): string {
    $remainder = strlen($input) % 4;
    if ($remainder) {
        $padlen = 4 - $remainder;
        $input .= str_repeat('=', $padlen);
    }
    return base64_decode(strtr($input, '-_', '+/'));
}

/**
 * Cryptographically verifies Firebase ID token claims and signature
 *
 * @param string $token
 * @return array|null Decoded verified token claims (uid, email, name) or null if invalid
 */
function verifyFirebaseIdToken(string $token): ?array {
    $token = trim($token);
    if (empty($token)) {
        error_log("[Auth Diagnostic] Bearer token is empty");
        return null;
    }

    // Ensure token is formatted as a 3-part JWT
    $jwtParts = explode('.', $token);
    if (count($jwtParts) !== 3) {
        error_log("[Auth Diagnostic] Invalid JWT structure (parts: " . count($jwtParts) . ")");
        return null;
    }

    list($headB64, $payloadB64, $sigB64) = $jwtParts;

    $header  = json_decode(base64UrlDecode($headB64), true);
    $payload = json_decode(base64UrlDecode($payloadB64), true);

    if (!$header || !$payload) {
        error_log("[Auth Diagnostic] Unable to decode JWT header or payload");
        return null;
    }

    // Check Expiration (Allow 300s clock skew for shared hosting system time drift)
    $now = time();
    $exp = (int)($payload['exp'] ?? 0);
    if ($exp <= 0 || $exp < ($now - 300)) {
        error_log("[Auth Diagnostic] Firebase ID Token expired (exp: {$exp}, now: {$now})");
        return null;
    }

    // Check Project Audience & Issuer
    $expectedProjId = FIREBASE_PROJECT_ID;
    $aud = $payload['aud'] ?? '';
    $iss = $payload['iss'] ?? '';
    $expectedIss = 'https://securetoken.google.com/' . $expectedProjId;

    if (!empty($expectedProjId)) {
        if ($aud !== $expectedProjId) {
            error_log("[Auth Diagnostic] Token audience '{$aud}' does not match expected project ID '{$expectedProjId}'");
            return null;
        }
        if ($iss !== $expectedIss) {
            error_log("[Auth Diagnostic] Token issuer '{$iss}' does not match expected issuer '{$expectedIss}'");
            return null;
        }
    }

    $uid   = trim($payload['user_id'] ?? $payload['sub'] ?? '');
    $email = strtolower(trim($payload['email'] ?? ''));

    if (empty($uid)) {
        error_log("[Auth Diagnostic] Token payload missing user_id/sub claim");
        return null;
    }

    // Method 1: Google OAuth2 TokenInfo Verification Endpoint
    $verifyUrl = 'https://oauth2.googleapis.com/tokeninfo?id_token=' . urlencode($token);

    $ch = curl_init();
    curl_setopt($ch, CURLOPT_URL, $verifyUrl);
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
    curl_setopt($ch, CURLOPT_TIMEOUT, 10);
    curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false); // Relax SSL peer check for shared hosting cURL CA compatibility

    $response = curl_exec($ch);
    $httpCode = curl_getinfo($ch, CURLINFO_HTTP_CODE);
    $curlErr  = curl_error($ch);
    curl_close($ch);

    if ($httpCode === 200 && !empty($response)) {
        $tokenInfo = json_decode($response, true);
        if ($tokenInfo) {
            $verifiedUid = trim($tokenInfo['user_id'] ?? $tokenInfo['sub'] ?? '');
            if ($verifiedUid === $uid) {
                return [
                    'uid'   => $uid,
                    'email' => !empty($tokenInfo['email']) ? strtolower(trim($tokenInfo['email'])) : $email,
                    'name'  => !empty($payload['name']) ? $payload['name'] : (!empty($tokenInfo['name']) ? $tokenInfo['name'] : ($email ?: $uid))
                ];
            } else {
                error_log("[Auth Diagnostic] TokenInfo verified UID '{$verifiedUid}' does not match payload UID '{$uid}'");
            }
        }
    } else {
        error_log("[Auth Diagnostic] TokenInfo endpoint HTTP status {$httpCode}, cURL error: " . ($curlErr ?: 'None'));
    }

    // Method 2: RS256 Signature verification using Google x509 public certificates
    $kid = $header['kid'] ?? null;
    $alg = $header['alg'] ?? null;

    if ($alg === 'RS256' && !empty($kid) && function_exists('openssl_verify')) {
        $keysUrl = 'https://www.googleapis.com/robot/v1/metadata/x509/securetoken@system.gserviceaccount.com';

        $ch = curl_init();
        curl_setopt($ch, CURLOPT_URL, $keysUrl);
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
        curl_setopt($ch, CURLOPT_TIMEOUT, 10);
        curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
        $keysJson = curl_exec($ch);
        curl_close($ch);

        if (!$keysJson) {
            $keysJson = @file_get_contents($keysUrl);
        }

        if ($keysJson) {
            $certs = json_decode($keysJson, true);
            if (isset($certs[$kid])) {
                $pubKeyCert  = $certs[$kid];
                $keyResource = openssl_pkey_get_public($pubKeyCert);

                if ($keyResource !== false) {
                    $dataToVerify = $headB64 . '.' . $payloadB64;
                    $signature    = base64UrlDecode($sigB64);

                    $verified = openssl_verify($dataToVerify, $signature, $keyResource, OPENSSL_ALGO_SHA256);
                    if (function_exists('openssl_free_key')) {
                        @openssl_free_key($keyResource);
                    }

                    if ($verified === 1) {
                        return [
                            'uid'   => $uid,
                            'email' => $email,
                            'name'  => !empty($payload['name']) ? $payload['name'] : (!empty($email) ? $email : $uid)
                        ];
                    } else {
                        error_log("[Auth Diagnostic] OpenSSL RS256 verification failed (code: {$verified})");
                    }
                }
            }
        }
    }

    error_log("[Auth Diagnostic] All Firebase ID token verification methods failed");
    return null;
}

/**
 * Authenticates request, verifies token claims, and connects user to MySQL database
 *
 * @param bool $required If true, terminates execution with 401 on failure
 * @return array|null MySQL user record or null
 */
function authenticateUser(bool $required = true): ?array {
    $token = getBearerToken();

    if (!$token) {
        error_log("[Auth Diagnostic] Request missing Bearer authorization token");
        if ($required) {
            sendJsonResponse([
                'success' => false,
                'error'   => 'Authentication required. Missing Bearer authorization header.'
            ], 401);
        }
        return null;
    }

    $verified = verifyFirebaseIdToken($token);

    if (!$verified) {
        error_log("[Auth Diagnostic] Token cryptographic verification failed");
        if ($required) {
            sendJsonResponse([
                'success' => false,
                'error'   => 'Invalid, expired, or unverified authentication token.'
            ], 401);
        }
        return null;
    }

    $db = getDbConnection();

    $email = strtolower($verified['email']);
    $adminUid   = defined('ADMIN_FIREBASE_UID') ? trim(ADMIN_FIREBASE_UID) : '';
    $adminEmail = defined('ADMIN_FIREBASE_EMAIL') ? strtolower(trim(ADMIN_FIREBASE_EMAIL)) : '';

    $isSoleAdmin = false;
    if (!empty($adminUid) && $verified['uid'] === $adminUid) {
        $isSoleAdmin = true;
    } elseif (!empty($adminEmail) && !empty($email) && $email === $adminEmail) {
        $isSoleAdmin = true;
    }

    // 1. Query MySQL users table by verified Firebase UID
    $stmt = $db->prepare("SELECT * FROM users WHERE firebase_uid = :uid LIMIT 1");
    $stmt->execute([':uid' => $verified['uid']]);
    $user = $stmt->fetch();

    // 2. If not found by UID, query by email to link existing seeded user account
    if (!$user && !empty($email)) {
        $stmtEmail = $db->prepare("SELECT * FROM users WHERE LOWER(email) = LOWER(:email) LIMIT 1");
        $stmtEmail->execute([':email' => $email]);
        $user = $stmtEmail->fetch();

        if ($user) {
            // Update firebase_uid on matched account
            $updUid = $db->prepare("UPDATE users SET firebase_uid = :uid WHERE id = :id");
            $updUid->execute([':uid' => $verified['uid'], ':id' => $user['id']]);
            $user['firebase_uid'] = $verified['uid'];
        }
    }

    if (!$user) {
        // Auto-provision new user record in MySQL using verified server claims ONLY
        $targetRole = $isSoleAdmin ? 'admin' : 'user';

        $insertStmt = $db->prepare("
            INSERT INTO users (firebase_uid, email, display_name, role)
            VALUES (:uid, :email, :name, :role)
        ");
        $insertStmt->execute([
            ':uid'   => $verified['uid'],
            ':email' => !empty($email) ? $email : 'user_' . substr($verified['uid'], 0, 8) . '@store.local',
            ':name'  => $verified['name'],
            ':role'  => $targetRole
        ]);

        $newId = $db->lastInsertId();
        $user = [
            'id'           => $newId,
            'firebase_uid' => $verified['uid'],
            'email'        => $email,
            'display_name' => $verified['name'],
            'role'         => $targetRole
        ];
    } else {
        // Automatically sync admin role ONLY if verified sole administrator Firebase UID or Email match
        if ($isSoleAdmin && $user['role'] !== 'admin') {
            $updateStmt = $db->prepare("UPDATE users SET role = 'admin' WHERE id = :id");
            $updateStmt->execute([':id' => $user['id']]);
            $user['role'] = 'admin';
        }
    }

    $user['is_admin'] = ($user['role'] === 'admin');
    return $user;
}

/**
 * Enforces Administrator access control
 *
 * @return array Admin user record from MySQL
 */
function requireAdmin(): array {
    $user = authenticateUser(true);

    if (!$user) {
        error_log("[Auth Diagnostic] requireAdmin failed: No authenticated user");
        sendJsonResponse([
            'success' => false,
            'error'   => 'Authentication required.'
        ], 401);
    }

    if ($user['role'] !== 'admin') {
        error_log("[Auth Diagnostic] requireAdmin failed: User ID {$user['id']} has role '{$user['role']}' (not admin)");
        sendJsonResponse([
            'success' => false,
            'error'   => 'Access denied. Administrator privileges required.'
        ], 403);
    }

    $adminUid   = defined('ADMIN_FIREBASE_UID') ? trim(ADMIN_FIREBASE_UID) : '';
    $adminEmail = defined('ADMIN_FIREBASE_EMAIL') ? strtolower(trim(ADMIN_FIREBASE_EMAIL)) : '';

    $isAuthorizedAdmin = false;
    if (!empty($adminUid) && $user['firebase_uid'] === $adminUid) {
        $isAuthorizedAdmin = true;
    }
    if (!empty($adminEmail) && !empty($user['email']) && strtolower($user['email']) === $adminEmail) {
        $isAuthorizedAdmin = true;
    }

    // If neither ADMIN_FIREBASE_UID nor ADMIN_FIREBASE_EMAIL is defined, trust DB role 'admin'
    if (empty($adminUid) && empty($adminEmail)) {
        $isAuthorizedAdmin = true;
    }

    if (!$isAuthorizedAdmin) {
        error_log("[Auth Diagnostic] requireAdmin failed: User UID '{$user['firebase_uid']}' / email '{$user['email']}' not recognized as authorized admin");
        sendJsonResponse([
            'success' => false,
            'error'   => 'Access denied. Administrator privileges required.'
        ], 403);
    }

    return $user;
}
