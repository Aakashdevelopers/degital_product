<?php
/**
 * NovaStore Private Database Configuration File Example
 *
 * RECOMMENDED SETUP FOR SHARED HOSTING:
 * 1. Create a file named `db_config.php` outside your public web root (`htdocs`),
 *    for example at `/home/YOUR_ACCOUNT/db_config.php` or `../db_config.php`.
 * 2. Copy the contents below into `db_config.php` and set your actual hosting MySQL password.
 * 3. `config/config.php` will automatically detect and load `db_config.php`.
 */

define('DB_HOST', 'sql204.ezyro.com');
define('DB_NAME', 'ezyro_43263892_digital_store');
define('DB_USER', 'ezyro_43263892');
define('DB_PASS', 'YOUR_ACTUAL_VPANEL_MYSQL_PASSWORD');
define('DB_PORT', '3306');
define('DB_CHARSET', 'utf8mb4');
