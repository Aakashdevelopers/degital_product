<?php
/**
 * ZapUPI Payment Gateway Configuration Template
 *
 * Copy this file to config/zapupi_config.php or set environment variable ZAPUPI_API_KEY.
 * Replace ZAPUPI_API_KEY with your official API key from https://zapupi.com dashboard.
 */

// Define your secret API Key from ZapUPI Dashboard
define('ZAPUPI_API_KEY', 'zape130f0223c42f6d3ea28abdb82177929');

// Official ZapUPI Base URL & Endpoints
define('ZAPUPI_BASE_URL', 'https://pay.zapupi.com/api');
define('ZAPUPI_CREATE_ORDER_ENDPOINT', ZAPUPI_BASE_URL . '/create-order');
define('ZAPUPI_ORDER_STATUS_ENDPOINT', ZAPUPI_BASE_URL . '/order-status');
