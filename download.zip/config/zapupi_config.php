<?php
/**
 * ZapUPI Payment Gateway Configuration  (single source of truth for the API key)
 *
 * Designed for PHP 7.4+ / 8.x and shared hosting.
 * Security: never expose ZAPUPI_API_KEY in client-side HTML/JS or API responses.
 * config/ is blocked from the web by .htaccess, but do NOT commit this file to a public repo.
 */

// 1. Optional: key file kept outside the document root
$outsideZapupiConfig = dirname(dirname(dirname(__DIR__))) . '/zapupi_config.php';
$parentZapupiConfig  = dirname(dirname(__DIR__)) . '/zapupi_config.php';

if (file_exists($outsideZapupiConfig) && is_readable($outsideZapupiConfig)) {
    require_once $outsideZapupiConfig;
} elseif (file_exists($parentZapupiConfig) && is_readable($parentZapupiConfig)) {
    require_once $parentZapupiConfig;
}

// 2. API key: outside file > environment variable > key stored below.
//    Placeholder values (YOUR_...) are ignored so a template value can never win.
if (!defined('ZAPUPI_API_KEY')) {
    $envKey = trim((string)getenv('ZAPUPI_API_KEY'));
    if ($envKey === '' || stripos($envKey, 'YOUR_') === 0) {
        $envKey = 'zape130f0223c42f6d3ea28abdb82177929';
    }
    define('ZAPUPI_API_KEY', $envKey);
}
if (!defined('ZAP_KEY')) {
    define('ZAP_KEY', ZAPUPI_API_KEY);
}

// Sandbox fulfillment is disabled by default. Set environment variable to 1 ONLY
// on a private/staging site. Keep 0/unset on the public production site.
if (!defined('ZAPUPI_ALLOW_TEST_FULFILLMENT')) {
    $allowTest = strtolower(trim((string)getenv('ZAPUPI_ALLOW_TEST_FULFILLMENT')));
    define('ZAPUPI_ALLOW_TEST_FULFILLMENT', in_array($allowTest, ['1', 'true', 'yes', 'on'], true));
}

// 3. Official ZapUPI endpoints
if (!defined('ZAPUPI_BASE_URL')) define('ZAPUPI_BASE_URL', 'https://pay.zapupi.com/api');
if (!defined('ZAPUPI_CREATE_ORDER_ENDPOINT')) define('ZAPUPI_CREATE_ORDER_ENDPOINT', ZAPUPI_BASE_URL . '/create-order');
if (!defined('ZAPUPI_ORDER_STATUS_ENDPOINT')) define('ZAPUPI_ORDER_STATUS_ENDPOINT', ZAPUPI_BASE_URL . '/order-status');
// Backward-compatible aliases
if (!defined('ZAPUPI_CREATE_ORDER_URL'))  define('ZAPUPI_CREATE_ORDER_URL', ZAPUPI_CREATE_ORDER_ENDPOINT);
if (!defined('ZAPUPI_ORDER_STATUS_URL'))  define('ZAPUPI_ORDER_STATUS_URL', ZAPUPI_ORDER_STATUS_ENDPOINT);

// 4. TLS verification for calls to ZapUPI. Keep TRUE: these responses decide whether
//    a customer receives a paid product. Set to false ONLY if your host has a broken CA bundle.
if (!defined('ZAPUPI_SSL_VERIFY')) define('ZAPUPI_SSL_VERIFY', true);

/**
 * Returns the ZapUPI API key, or '' when it is missing / still a placeholder.
 */
function getZapupiApiKey(): string {
    $key = defined('ZAPUPI_API_KEY') ? trim((string)ZAPUPI_API_KEY) : '';
    if ($key === '' || stripos($key, 'YOUR_') === 0) {
        return '';
    }
    return $key;
}

/**
 * Public base URL of this site (scheme + host), e.g. https://example.com
 */
function zapupiSiteBaseUrl(): string {
    $https = (!empty($_SERVER['HTTPS']) && $_SERVER['HTTPS'] !== 'off')
          || (($_SERVER['HTTP_X_FORWARDED_PROTO'] ?? '') === 'https');
    $host = $_SERVER['HTTP_HOST'] ?? 'localhost';
    return ($https ? 'https' : 'http') . '://' . $host;
}

/**
 * POST a payload to a ZapUPI endpoint.
 * ZapUPI documents JSON bodies, so JSON is tried first; if the reply is not JSON
 * the same call is retried once as form-encoded.
 *
 * @return array ['ok'=>bool, 'http'=>int, 'data'=>?array, 'raw'=>string, 'error'=>string]
 */
function zapupiPost(string $url, array $payload): array {
    $result = ['ok' => false, 'http' => 0, 'data' => null, 'raw' => '', 'error' => ''];
    if (!function_exists('curl_init')) {
        $result['error'] = 'PHP cURL extension is not enabled';
        return $result;
    }

    // ZapUPI's documented request format is JSON. Do not repeat a payment
    // creation request in a second format because it may create duplicate orders.
    $body = json_encode($payload, JSON_INVALID_UTF8_SUBSTITUTE);
    if ($body === false) {
        $result['error'] = 'Unable to encode request JSON';
        return $result;
    }

    $ch = curl_init($url);
    curl_setopt_array($ch, [
        CURLOPT_POST => true,
        CURLOPT_POSTFIELDS => $body,
        CURLOPT_RETURNTRANSFER => true,
        CURLOPT_HTTPHEADER => [
            'Content-Type: application/json',
            'Accept: application/json',
            'User-Agent: DigitalStoreZapUPI/2.1'
        ],
        CURLOPT_TIMEOUT => 15,
        CURLOPT_CONNECTTIMEOUT => 10,
        CURLOPT_SSL_VERIFYPEER => ZAPUPI_SSL_VERIFY,
        CURLOPT_SSL_VERIFYHOST => ZAPUPI_SSL_VERIFY ? 2 : 0,
        CURLOPT_FOLLOWLOCATION => false
    ]);
    $raw = curl_exec($ch);
    $result['http'] = (int)curl_getinfo($ch, CURLINFO_HTTP_CODE);
    $result['error'] = curl_error($ch);
    $result['raw'] = is_string($raw) ? $raw : '';
    curl_close($ch);

    if ($result['error'] !== '') return $result;
    $decoded = json_decode($result['raw'], true);
    if (!is_array($decoded)) {
        $result['error'] = 'ZapUPI returned non-JSON response';
        return $result;
    }
    $result['data'] = $decoded;
    $result['ok'] = ($result['http'] >= 200 && $result['http'] < 300);
    if (!$result['ok'] && $result['error'] === '') {
        $result['error'] = 'ZapUPI HTTP ' . $result['http'];
    }
    return $result;
}
