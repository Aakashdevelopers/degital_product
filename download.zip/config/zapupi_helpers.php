<?php
/**
 * Shared ZapUPI verification and fulfilment helpers.
 * Payment access is granted only after server-to-server status verification.
 */
require_once __DIR__ . '/config.php';
require_once __DIR__ . '/zapupi_config.php';

function zapupiScalarString($value): string {
    return is_scalar($value) ? trim((string)$value) : '';
}

function zapupiFindOrderPayload(array $body): array {
    $queue = [$body];
    foreach (['data', 'order', 'payment', 'result', 'transaction'] as $key) {
        if (isset($body[$key]) && is_array($body[$key])) $queue[] = $body[$key];
    }
    foreach ($queue as $candidate) {
        foreach (['data', 'order', 'payment', 'result', 'transaction'] as $key) {
            if (isset($candidate[$key]) && is_array($candidate[$key])) $queue[] = $candidate[$key];
        }
        if (isset($candidate['order_status']) || isset($candidate['payment_status']) || isset($candidate['txn_id']) || isset($candidate['transaction_id'])) {
            return $candidate;
        }
        // A nested data.status may be the order status when the top-level status is API success.
        if (isset($candidate['status']) && !in_array(strtolower((string)$candidate['status']), ['success', 'ok'], true)) {
            return $candidate;
        }
    }
    // Return data object if it exists, otherwise the response. Caller still checks API and payment status separately.
    return (isset($body['data']) && is_array($body['data'])) ? $body['data'] : $body;
}

function zapupiNormalizePaymentStatus($value): string {
    $status = strtoupper(trim(zapupiScalarString($value)));
    $map = [
        'SUCCESSFUL' => 'SUCCESS', 'COMPLETED' => 'SUCCESS', 'PAID' => 'SUCCESS',
        'PAYMENT_SUCCESS' => 'SUCCESS', 'PAYMENT SUCCESS' => 'SUCCESS',
        'PAYMENT_FAILED' => 'FAILED', 'PAYMENT FAILED' => 'FAILED',
        'FAIL' => 'FAILED', 'FAILURE' => 'FAILED', 'DECLINED' => 'FAILED', 'ERROR' => 'FAILED',
        'PAYMENT_DECLINED' => 'FAILED', 'PAYMENT ERROR' => 'FAILED',
        'CANCELED' => 'CANCELLED', 'CANCEL' => 'CANCELLED', 'TIMEOUT' => 'EXPIRED', 'TIMED_OUT' => 'EXPIRED'
    ];
    return $map[$status] ?? $status;
}

/** Returns normalized remote state; amount must be present to fulfil an order. */
function zapupiFetchRemoteStatus(string $orderId): array {
    $out = [
        'api_ok' => false, 'status' => '', 'amount_paise' => 0, 'amount_present' => false,
        'txn_id' => '', 'utr' => '', 'env' => '', 'is_test' => false,
        'is_paid' => false, 'is_failed' => false, 'raw' => []
    ];
    $apiKey = function_exists('getZapupiApiKey') ? getZapupiApiKey() : '';
    if ($apiKey === '') {
        error_log('[ZapUPI] Missing API key; cannot verify order ' . $orderId);
        return $out;
    }
    $res = zapupiPost(ZAPUPI_ORDER_STATUS_ENDPOINT, ['zap_key' => $apiKey, 'order_id' => $orderId]);
    if (empty($res['ok']) || !is_array($res['data'] ?? null)) {
        error_log('[ZapUPI] Status request failed for ' . $orderId . ': ' . ($res['error'] ?: ('HTTP ' . $res['http'])));
        return $out;
    }
    $body = $res['data'];
    $order = zapupiFindOrderPayload($body);
    $out['raw'] = $body;
    $topStatus = strtolower(zapupiScalarString($body['status'] ?? ''));
    $out['api_ok'] = in_array($topStatus, ['success', 'ok'], true);
    $out['status'] = zapupiNormalizePaymentStatus(
        $order['payment_status'] ?? $order['order_status'] ?? $order['status'] ?? $body['order_status'] ?? ''
    );
    $txn = $order['txn_id'] ?? $order['transaction_id'] ?? $order['transactionId'] ?? $order['txnId'] ?? '';
    $out['txn_id'] = sanitizeString($txn);
    $out['utr'] = sanitizeString($order['utr'] ?? $order['rrn'] ?? $order['bank_reference'] ?? '');
    $out['env'] = strtolower(sanitizeString($order['environment'] ?? $order['mode'] ?? $body['environment'] ?? ''));

    $amount = $order['amount'] ?? $order['paid_amount'] ?? $order['transaction_amount'] ?? $order['amount_inr'] ?? $order['paidAmount'] ?? $order['txn_amount'] ?? $order['total_amount'] ?? null;
    if (is_numeric($amount) && (float)$amount > 0) {
        $out['amount_paise'] = (int)round((float)$amount * 100); // ZapUPI amount is expected in INR
        $out['amount_present'] = true;
    } elseif (isset($order['amount_in_paise']) && is_numeric($order['amount_in_paise']) && (int)$order['amount_in_paise'] > 0) {
        $out['amount_paise'] = (int)$order['amount_in_paise'];
        $out['amount_present'] = true;
    }

    $txnLower = strtolower($out['txn_id']);
    $out['is_test'] = in_array($out['env'], ['test', 'sandbox'], true)
        || strpos($txnLower, 'dummy') === 0
        || stripos(zapupiScalarString($body['message'] ?? ''), 'sandbox') !== false;
    $allowTest = defined('ZAPUPI_ALLOW_TEST_FULFILLMENT') && ZAPUPI_ALLOW_TEST_FULFILLMENT === true;
    $out['is_paid'] = $out['api_ok'] && $out['status'] === 'SUCCESS'
        && (!$out['is_test'] || $allowTest) && $out['amount_present'];
    $out['is_failed'] = $out['api_ok'] && in_array($out['status'], ['FAILED', 'EXPIRED', 'CANCELLED'], true);
    return $out;
}

/** Returns completed|failed|pending|test|amount_mismatch. */
function zapupiSettleOrder(PDO $db, array $localOrder): string {
    if (($localOrder['status'] ?? '') === 'completed') return 'completed';
    if (empty($localOrder['id']) || empty($localOrder['order_id'])) return 'pending';

    $remote = zapupiFetchRemoteStatus((string)$localOrder['order_id']);
    if ($remote['is_test'] && !(defined('ZAPUPI_ALLOW_TEST_FULFILLMENT') && ZAPUPI_ALLOW_TEST_FULFILLMENT === true)) {
        error_log('[ZapUPI] Sandbox transaction blocked by configuration for ' . $localOrder['order_id']);
        return 'test';
    }

    if ($remote['is_failed']) {
        $stmt = $db->prepare("UPDATE payment_orders SET status='failed', raw_response=:raw WHERE id=:id AND status='pending'");
        $stmt->execute([':raw' => json_encode($remote['raw']), ':id' => $localOrder['id']]);
        return 'failed';
    }
    if (!$remote['is_paid']) {
        error_log('[ZapUPI] Not yet verified for ' . $localOrder['order_id'] . '; api_ok=' . (int)$remote['api_ok'] . '; status=' . $remote['status'] . '; amount_present=' . (int)$remote['amount_present']);
        return 'pending';
    }

    $expected = (int)($localOrder['amount_in_paise'] ?? 0);
    if ($expected <= 0 || !$remote['amount_present'] || $remote['amount_paise'] !== $expected) {
        error_log('[ZapUPI] Amount mismatch/missing for ' . $localOrder['order_id'] . '; expected=' . $expected . '; received=' . $remote['amount_paise']);
        return 'amount_mismatch';
    }

    try {
        $db->beginTransaction();
        $upd = $db->prepare("UPDATE payment_orders SET status='completed', zapupi_txn_id=:txn, utr=:utr, raw_response=:raw WHERE id=:id AND status='pending'");
        $upd->execute([
            ':txn' => $remote['txn_id'], ':utr' => $remote['utr'],
            ':raw' => json_encode($remote['raw']), ':id' => $localOrder['id']
        ]);
        if ($upd->rowCount() !== 1) {
            $db->rollBack();
            $check = $db->prepare('SELECT status FROM payment_orders WHERE id=? LIMIT 1');
            $check->execute([$localOrder['id']]);
            return $check->fetchColumn() === 'completed' ? 'completed' : 'pending';
        }

        // Optional legacy table, not required for checkout verification.
        try {
            $legacy = $db->prepare("UPDATE zap_orders SET status='Success', utr=:utr, txn_id=:txn, paid_at=NOW() WHERE order_id=:oid");
            $legacy->execute([':utr'=>$remote['utr'], ':txn'=>$remote['txn_id'], ':oid'=>$localOrder['order_id']]);
        } catch (Throwable $ignored) {}

        $purchase = $db->prepare("INSERT INTO purchases
            (user_id, firebase_uid, product_id, user_email, phone_number, purchase_type, status, price_snapshot_in_paise)
            VALUES (:uid, :fuid, :pid, :email, :phone, 'zapupi', 'granted', :price)
            ON DUPLICATE KEY UPDATE purchase_type='zapupi', status='granted', price_snapshot_in_paise=VALUES(price_snapshot_in_paise), updated_at=CURRENT_TIMESTAMP");
        $purchase->execute([
            ':uid'=>$localOrder['user_id'], ':fuid'=>$localOrder['firebase_uid'],
            ':pid'=>$localOrder['product_id'], ':email'=>$localOrder['customer_email'],
            ':phone'=>$localOrder['customer_phone'] ?? '', ':price'=>$expected
        ]);
        $db->commit();
        error_log('[ZapUPI] Verified and fulfilled order ' . $localOrder['order_id']);
        return 'completed';
    } catch (Throwable $e) {
        if ($db->inTransaction()) $db->rollBack();
        error_log('[ZapUPI DB] Fulfilment failed for ' . $localOrder['order_id'] . ': ' . $e->getMessage());
        return 'pending';
    }
}
