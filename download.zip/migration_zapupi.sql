-- ==============================================================================
-- ZapUPI Payment Gateway Integration - Non-Destructive Database Migration
-- Suitable for phpMyAdmin, MySQL 5.7+, MySQL 8.x, and MariaDB
-- ==============================================================================

SET FOREIGN_KEY_CHECKS = 0;

-- ------------------------------------------------------------------------------
-- Table: payment_orders
-- Stores unique payment intent records, amounts, ZapUPI order status and UTR
-- ------------------------------------------------------------------------------
CREATE TABLE IF NOT EXISTS `payment_orders` (
  `id` INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  `order_id` VARCHAR(100) NOT NULL,
  `user_id` INT UNSIGNED NOT NULL,
  `firebase_uid` VARCHAR(128) NOT NULL,
  `product_id` INT UNSIGNED NOT NULL,
  `customer_email` VARCHAR(191) NOT NULL,
  `customer_phone` VARCHAR(50) DEFAULT '',
  `amount_in_paise` BIGINT UNSIGNED NOT NULL,
  `status` ENUM('pending', 'completed', 'failed', 'expired') NOT NULL DEFAULT 'pending',
  `zapupi_txn_id` VARCHAR(100) DEFAULT NULL,
  `utr` VARCHAR(100) DEFAULT NULL,
  `payment_url` TEXT DEFAULT NULL,
  `raw_response` TEXT DEFAULT NULL,
  `created_at` DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  UNIQUE KEY `uk_payment_orders_order_id` (`order_id`),
  INDEX `idx_payment_orders_user_product` (`user_id`, `product_id`),
  INDEX `idx_payment_orders_status` (`status`),
  CONSTRAINT `fk_payment_orders_user` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `fk_payment_orders_product` FOREIGN KEY (`product_id`) REFERENCES `products` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ------------------------------------------------------------------------------
-- Table: zap_orders (For standalone module compatibility)
-- ------------------------------------------------------------------------------
CREATE TABLE IF NOT EXISTS `zap_orders` (
  `id` INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  `order_id` VARCHAR(100) NOT NULL,
  `txn_id` VARCHAR(100) DEFAULT '',
  `amount` DECIMAL(10,2) NOT NULL,
  `status` ENUM('pending','Success','Failed') DEFAULT 'pending',
  `utr` VARCHAR(100) DEFAULT '',
  `customer_mobile` VARCHAR(20) DEFAULT '',
  `remark` VARCHAR(500) DEFAULT '',
  `paid_at` DATETIME DEFAULT NULL,
  `created_at` DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  UNIQUE KEY `uk_zap_orders_order_id` (`order_id`),
  INDEX `idx_zap_orders_status` (`status`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ------------------------------------------------------------------------------
-- Update `purchases` table ENUMs to allow 'zapupi' and 'paid' purchase types
-- ------------------------------------------------------------------------------
ALTER TABLE `purchases` MODIFY COLUMN `purchase_type` ENUM('demo', 'zapupi', 'paid') NOT NULL DEFAULT 'demo';
ALTER TABLE `purchases` MODIFY COLUMN `status` ENUM('granted', 'completed') NOT NULL DEFAULT 'granted';

SET FOREIGN_KEY_CHECKS = 1;
