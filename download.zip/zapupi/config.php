<?php
/**
 * ZapUPI Payment Gateway Configuration
 * Standalone & Integrated Module
 */

if (file_exists(__DIR__ . '/../config/zapupi_config.php')) {
    require_once __DIR__ . '/../config/zapupi_config.php';
}
if (file_exists(__DIR__ . '/../config/config.php')) {
    require_once __DIR__ . '/../config/config.php';
}

if (!defined('ZAP_KEY')) {
    define('ZAP_KEY', defined('ZAPUPI_API_KEY') ? ZAPUPI_API_KEY : 'zape130f0223c42f6d3ea28abdb82177929');
}
if (!defined('ZAP_API_BASE')) {
    define('ZAP_API_BASE', 'https://pay.zapupi.com/api');
}

// ── Auto-detect Base URL ──────────────────────────────
$protocol = (!empty($_SERVER['HTTPS']) && $_SERVER['HTTPS'] !== 'off') ? 'https' : 'http';
$domain   = $_SERVER['HTTP_HOST'] ?? 'localhost';
$folder   = rtrim(dirname($_SERVER['SCRIPT_NAME']), '/\\');

// Canonical Base URL
define('BASE_URL', $protocol . '://' . $domain . $folder);

// ── Webhook & Redirect URLs ───────────────────────────
define('WEBHOOK_URL',     BASE_URL . '/webhook.php');
define('SUCCESS_URL',     BASE_URL . '/success.php');
define('FAILED_URL',      BASE_URL . '/failed.php');
define('TIMEOUT_URL',     BASE_URL . '/timeout.php');

// ── Database Credentials Fallback ─────────────────────
if (!defined('DB_HOST')) define('DB_HOST', getenv('DB_HOST') ?: 'sql204.ezyro.com');
if (!defined('DB_NAME')) define('DB_NAME', getenv('DB_NAME') ?: 'ezyro_43263892_digital_store');
if (!defined('DB_USER')) define('DB_USER', getenv('DB_USER') ?: 'ezyro_43263892');
if (!defined('DB_PASS')) define('DB_PASS', (getenv('DB_PASS') !== false && getenv('DB_PASS') !== '') ? getenv('DB_PASS') : '2bda86ac34c1');

/**
 * Returns a Singleton PDO Connection for ZapUPI Operations
 *
 * @return PDO
 */
function zapDB() {
    if (function_exists('getDbConnection')) {
        return getDbConnection();
    }
    static $pdo = null;
    if ($pdo === null) {
        try {
            $pdo = new PDO(
                'mysql:host=' . DB_HOST . ';dbname=' . DB_NAME . ';charset=utf8mb4',
                DB_USER,
                DB_PASS,
                [
                    PDO::ATTR_ERRMODE            => PDO::ERRMODE_EXCEPTION,
                    PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
                    PDO::MYSQL_ATTR_INIT_COMMAND => "SET NAMES utf8mb4 COLLATE utf8mb4_unicode_ci"
                ]
            );
        } catch (PDOException $e) {
            error_log('[ZapDB Error] Connection failed: ' . $e->getMessage());
            die(json_encode(['status' => 'error', 'message' => 'Database connection failed.']));
        }
    }
    return $pdo;
}
