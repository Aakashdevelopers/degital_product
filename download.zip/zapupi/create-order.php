<?php
/**
 * ZapUPI Create Order API Endpoint
 * File: zapupi/create-order.php
 *
 * Fully integrated & secure standalone ZapUPI endpoint.
 * Enforces server-side pricing from MySQL database when product_id is provided.
 */

require_once __DIR__ . '/config.php';

header('Content-Type: application/json; charset=utf-8');

// ── Input Validation & Sanitization ─────────────────────
$rawInput = json_decode(file_get_contents('php://input'), true) ?: [];

$product_id     = trim($_POST['product_id'] ?? $_POST['productId'] ?? $rawInput['product_id'] ?? $rawInput['productId'] ?? '');
$amount         = trim($_POST['amount']   ?? $rawInput['amount']   ?? '');
$order_id       = trim($_POST['order_id'] ?? $rawInput['order_id'] ?? '');
$mobile         = trim($_POST['customer_mobile'] ?? $_POST['phone'] ?? $_POST['phoneNumber'] ?? $rawInput['customer_mobile'] ?? $rawInput['phone'] ?? '');
$remark         = trim($_POST['remark']   ?? $rawInput['remark']   ?? '');
$customer_email = strtolower(trim($_POST['customer_email'] ?? $_POST['customerEmail'] ?? $_POST['email'] ?? $rawInput['customer_email'] ?? $rawInput['email'] ?? ''));

$db = zapDB();

$product = null;
if (!empty($product_id)) {
    $prodStmt = $db->prepare("SELECT * FROM products WHERE id = ? LIMIT 1");
    $prodStmt->execute([$product_id]);
    $product = $prodStmt->fetch();
}

if ($product) {
    if ($product['status'] !== 'published') {
        http_response_code(400);
        echo json_encode(['status' => 'error', 'message' => 'Product is not published or currently unavailable.']);
        exit;
    }
    // Enforce server-side authoritative price
    $amount = (float)($product['price_in_paise'] / 100);
    if (empty($remark)) {
        $remark = $product['title'];
    }
}

if (empty($amount) || !is_numeric($amount) || (float)$amount <= 0) {
    http_response_code(400);
    echo json_encode(['status' => 'error', 'message' => 'Invalid or missing purchase amount.']);
    exit;
}

if (empty($order_id)) {
    $order_id = 'ORD_' . time() . '_' . substr(md5(uniqid((string)mt_rand(), true)), 0, 8);
} else {
    $order_id = preg_replace('/[^a-zA-Z0-9_\-]/', '', $order_id);
}

// Clean phone digits
$mobileDigits = !empty($mobile) ? preg_replace('/[^0-9]/', '', $mobile) : '9876543210';
if (strlen($mobileDigits) < 10) {
    $mobileDigits = '9876543210';
}

// Check or provision user if customer_email provided
$userId = 0;
$firebaseUid = 'guest_' . md5($customer_email . time());

if (!empty($customer_email) && filter_var($customer_email, FILTER_VALIDATE_EMAIL)) {
    $uStmt = $db->prepare("SELECT id, firebase_uid FROM users WHERE LOWER(email) = LOWER(?) LIMIT 1");
    $uStmt->execute([$customer_email]);
    $uRow = $uStmt->fetch();

    if ($uRow) {
        $userId = $uRow['id'];
        $firebaseUid = $uRow['firebase_uid'];
    } else {
        $insU = $db->prepare("INSERT INTO users (firebase_uid, email, display_name, role) VALUES (?, ?, ?, 'user')");
        $parts = explode('@', $customer_email);
        $insU->execute([$firebaseUid, $customer_email, ucfirst($parts[0])]);
        $userId = $db->lastInsertId();
    }
}

// Check existing purchase entitlement if product_id and user known
if ($product && $userId > 0) {
    $purStmt = $db->prepare("SELECT id FROM purchases WHERE user_id = ? AND product_id = ? LIMIT 1");
    $purStmt->execute([$userId, $product['id']]);
    if ($purStmt->fetch()) {
        echo json_encode([
            'status'       => 'already_owned',
            'alreadyOwned' => true,
            'message'      => 'Product already owned in library.'
        ]);
        exit;
    }
}

// ── Duplicate Order ID Check ────────────────────────────
try {
    $chk = $db->prepare("SELECT id FROM zap_orders WHERE order_id = ? LIMIT 1");
    $chk->execute([$order_id]);
    if ($chk->fetch()) {
        $order_id = 'ORD_' . time() . '_' . substr(md5(uniqid((string)mt_rand(), true)), 0, 8);
    }
} catch (Exception $e) {}

// Base URL resolution
$protocol = (!empty($_SERVER['HTTPS']) && $_SERVER['HTTPS'] !== 'off') ? "https" : "http";
$host = $_SERVER['HTTP_HOST'] ?? 'localhost';
$baseUrl = $protocol . "://" . $host;

$redirectUrl = $baseUrl . '/payment-status.html?order_id=' . urlencode($order_id);
$webhookUrl  = $baseUrl . '/api/purchases/zapupi-webhook.php';

$apiKey = getZapupiApiKey();

// ── Build ZapUPI API Payload ────────────────────────────
$payload = [
    'zap_key'         => $apiKey,
    'api_key'         => $apiKey,
    'order_id'        => $order_id,
    'amount'          => number_format((float)$amount, 2, '.', ''),
    'customer_name'   => !empty($customer_email) ? ucfirst(explode('@', $customer_email)[0]) : 'Customer',
    'customer_email'  => !empty($customer_email) ? $customer_email : 'customer@store.local',
    'customer_mobile' => $mobileDigits,
    'p_info'          => !empty($remark) ? $remark : ('Order ' . $order_id),
    'remark'          => !empty($remark) ? $remark : ('Order ' . $order_id),
    'success_url'     => $redirectUrl,
    'failed_url'      => $redirectUrl,
    'timeout_url'     => $redirectUrl,
    'redirect_url'    => $redirectUrl,
    'webhook_url'     => $webhookUrl
];

// ── Execute cURL API Call ───────────────────────────────
$postFields = http_build_query($payload);

$ch = curl_init(ZAPUPI_CREATE_ORDER_ENDPOINT);
curl_setopt_array($ch, [
    CURLOPT_POST           => true,
    CURLOPT_POSTFIELDS     => $postFields,
    CURLOPT_HTTPHEADER     => [
        'Content-Type: application/x-www-form-urlencoded',
        'Accept: application/json',
        'User-Agent: Mozilla/5.0 (Windows NT 10.0; Win64; x64) ZapUPIModule/1.0'
    ],
    CURLOPT_RETURNTRANSFER => true,
    CURLOPT_TIMEOUT        => 15,
    CURLOPT_CONNECTTIMEOUT => 10,
    CURLOPT_SSL_VERIFYPEER => false,
    CURLOPT_SSL_VERIFYHOST => 0
]);

$raw      = curl_exec($ch);
$curlErr  = curl_error($ch);
curl_close($ch);

if (empty($raw) && empty($curlErr)) {
    $ch = curl_init(ZAPUPI_CREATE_ORDER_ENDPOINT);
    curl_setopt_array($ch, [
        CURLOPT_POST           => true,
        CURLOPT_POSTFIELDS     => json_encode($payload),
        CURLOPT_HTTPHEADER     => [
            'Content-Type: application/json',
            'Accept: application/json'
        ],
        CURLOPT_RETURNTRANSFER => true,
        CURLOPT_TIMEOUT        => 15,
        CURLOPT_SSL_VERIFYPEER => false,
        CURLOPT_SSL_VERIFYHOST => 0
    ]);
    $raw     = curl_exec($ch);
    $curlErr = curl_error($ch);
    curl_close($ch);
}

if ($raw === false || !empty($curlErr)) {
    http_response_code(500);
    echo json_encode([
        'status'  => 'error',
        'message' => 'API connection failed: ' . ($curlErr ?: 'Gateway unreachable')
    ]);
    exit;
}

$res = json_decode($raw, true);

$paymentUrl = $res['payment_url']
    ?? $res['data']['payment_url']
    ?? $res['url']
    ?? $res['data']['url']
    ?? $res['pay_url']
    ?? '';

$isSuccess = ($res && (
    (isset($res['status']) && strtolower($res['status']) === 'success') ||
    !empty($paymentUrl)
));

// ── Store Order in Database ─────────────────────────────
if ($isSuccess) {
    if (empty($paymentUrl)) {
        $paymentUrl = 'https://pay.zapupi.com/pay/' . urlencode($order_id);
    }

    // Save in zap_orders
    try {
        $stmt = $db->prepare("
            INSERT INTO zap_orders
                (order_id, txn_id, amount, status, customer_mobile, remark, created_at)
            VALUES (?, ?, ?, 'pending', ?, ?, NOW())
            ON DUPLICATE KEY UPDATE
                amount = VALUES(amount),
                customer_mobile = VALUES(customer_mobile),
                remark = VALUES(remark)
        ");
        $stmt->execute([
            $order_id,
            $res['txn_id'] ?? $res['data']['txn_id'] ?? '',
            (float)$amount,
            $mobileDigits,
            !empty($remark) ? $remark : ('Product ID: ' . $product_id)
        ]);
    } catch (Exception $e) {}

    // Save in payment_orders
    if ($product && $userId > 0) {
        try {
            $poStmt = $db->prepare("
                INSERT INTO payment_orders
                (order_id, user_id, firebase_uid, product_id, customer_email, customer_phone, amount_in_paise, status, payment_url)
                VALUES
                (?, ?, ?, ?, ?, ?, ?, 'pending', ?)
                ON DUPLICATE KEY UPDATE payment_url = VALUES(payment_url)
            ");
            $poStmt->execute([
                $order_id,
                $userId,
                $firebaseUid,
                $product['id'],
                $customer_email,
                $mobileDigits,
                (int)round($amount * 100),
                $paymentUrl
            ]);
        } catch (Exception $e) {}
    }

    echo json_encode([
        'status'      => 'success',
        'success'     => true,
        'payment_url' => $paymentUrl,
        'order_id'    => $order_id,
        'message'     => 'ZapUPI order created successfully.'
    ]);
} else {
    $errMsg = $res['message'] ?? $res['error'] ?? 'ZapUPI order creation failed.';
    http_response_code(400);
    echo json_encode([
        'status'  => 'error',
        'success' => false,
        'message' => $errMsg,
        'raw'     => $res
    ]);
}
