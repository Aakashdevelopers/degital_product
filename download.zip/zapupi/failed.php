<?php
/**
 * ZapUPI Payment Failed Page
 * File: zapupi/failed.php
 */

require_once __DIR__ . '/config.php';

$order_id = htmlspecialchars(trim($_GET['order_id'] ?? ''), ENT_QUOTES, 'UTF-8');

$order = null;
if (!empty($order_id)) {
    try {
        $db   = zapDB();
        $stmt = $db->prepare("SELECT * FROM zap_orders WHERE order_id = ? LIMIT 1");
        $stmt->execute([$order_id]);
        $order = $stmt->fetch();
    } catch (Exception $e) {
        error_log('[Failed Page Error] ' . $e->getMessage());
    }
}

$amountFormatted = $order ? number_format((float)$order['amount'], 2) : '0.00';
?>
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Payment Unsuccessful — ZapUPI</title>
  <link rel="stylesheet" href="assets/zapupi.css?v=1.0">
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
</head>
<body class="zap-body">

  <div class="zap-card zap-card-failed">
    <div class="zap-icon-circle zap-icon-failed">
      <i class="fa-solid fa-triangle-exclamation"></i>
    </div>

    <h1 class="zap-title">Payment Unsuccessful</h1>
    <p class="zap-subtitle">Your payment attempt could not be verified or was cancelled. No charges were completed.</p>

    <div class="zap-details-box">
      <div class="zap-detail-row">
        <span>Order ID:</span>
        <strong><?= $order_id ?: 'N/A' ?></strong>
      </div>
      <div class="zap-detail-row">
        <span>Amount:</span>
        <strong style="color: #991b1b;">₹<?= $amountFormatted ?></strong>
      </div>
      <div class="zap-detail-row">
        <span>Status:</span>
        <strong style="color: #dc2626;">Failed / Cancelled</strong>
      </div>
    </div>

    <div class="zap-btn-group">
      <a href="../index.html" class="zap-btn zap-btn-primary">
        <i class="fa-solid fa-rotate-right"></i> Try Payment Again
      </a>
      <a href="../index.html" class="zap-btn zap-btn-outline">
        Return to Storefront
      </a>
    </div>
  </div>

</body>
</html>
