-- ==============================================================================
-- ZapUPI Module Standalone Table Schema
-- ==============================================================================

CREATE TABLE IF NOT EXISTS zap_orders (
    id              INT AUTO_INCREMENT PRIMARY KEY,
    order_id        VARCHAR(100)  NOT NULL UNIQUE,
    txn_id          VARCHAR(100)  DEFAULT '',
    amount          DECIMAL(10,2) NOT NULL,
    status          ENUM('pending','Success','Failed') DEFAULT 'pending',
    utr             VARCHAR(100)  DEFAULT '',
    customer_mobile VARCHAR(20)   DEFAULT '',
    remark          VARCHAR(500)  DEFAULT '',
    paid_at         DATETIME      DEFAULT NULL,
    created_at      DATETIME      DEFAULT CURRENT_TIMESTAMP,
    INDEX idx_order_id (order_id),
    INDEX idx_status   (status)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
