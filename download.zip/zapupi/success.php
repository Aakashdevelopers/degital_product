<?php
/**
 * ZapUPI Payment Success Page
 * File: zapupi/success.php
 */

require_once __DIR__ . '/config.php';

$order_id = htmlspecialchars(trim($_GET['order_id'] ?? ''), ENT_QUOTES, 'UTF-8');
$utr      = htmlspecialchars(trim($_GET['utr']      ?? ''), ENT_QUOTES, 'UTF-8');

$db    = zapDB();
$order = null;

if (!empty($order_id)) {
    try {
        $poStmt = $db->prepare("SELECT po.*, prod.title, prod.resource_url FROM payment_orders po INNER JOIN products prod ON po.product_id = prod.id WHERE po.order_id = ? LIMIT 1");
        $poStmt->execute([$order_id]);
        $order = $poStmt->fetch();
    } catch (Exception $e) {
        error_log('[Success Page Error] ' . $e->getMessage());
    }
}

// Perform active server-side verification if status is pending
if ($order && $order['status'] === 'pending') {
    $apiKey = getZapupiApiKey();
    if (!empty($apiKey)) {
        $ch = curl_init(ZAP_API_BASE . '/order-status');
        $payload = http_build_query(['zap_key' => $apiKey, 'api_key' => $apiKey, 'order_id' => $order_id]);
        curl_setopt_array($ch, [
            CURLOPT_POST           => true,
            CURLOPT_POSTFIELDS     => $payload,
            CURLOPT_RETURNTRANSFER => true,
            CURLOPT_TIMEOUT        => 10,
            CURLOPT_SSL_VERIFYPEER => false,
            CURLOPT_SSL_VERIFYHOST => 0
        ]);
        $res = curl_exec($ch);
        curl_close($ch);
        $resData = json_decode($res, true);
        $orderData = ($resData && isset($resData['data']) && is_array($resData['data'])) ? $resData['data'] : $resData;

        $remoteStatus = strtoupper(trim($orderData['status'] ?? $resData['order_status'] ?? ''));
        $remoteTxn    = sanitizeString($orderData['txn_id'] ?? '');
        $remoteUtr    = sanitizeString($orderData['utr'] ?? $utr);

        if (in_array($remoteStatus, ['SUCCESS', 'COMPLETED', 'PAID', 'SUCCESSFUL'], true)) {
            try {
                $db->beginTransaction();
                $upd = $db->prepare("UPDATE payment_orders SET status = 'completed', zapupi_txn_id = ?, utr = ? WHERE id = ?");
                $upd->execute([$remoteTxn, $remoteUtr, $order['id']]);

                $insPur = $db->prepare("
                    INSERT INTO purchases (user_id, firebase_uid, product_id, user_email, phone_number, purchase_type, status, price_snapshot_in_paise)
                    VALUES (?, ?, ?, ?, ?, 'zapupi', 'granted', ?)
                    ON DUPLICATE KEY UPDATE status = 'granted', purchase_type = 'zapupi', updated_at = CURRENT_TIMESTAMP
                ");
                $insPur->execute([$order['user_id'], $order['firebase_uid'], $order['product_id'], $order['customer_email'], $order['customer_phone'], $order['amount_in_paise']]);
                $db->commit();
                $order['status'] = 'completed';
            } catch (Exception $e) {
                if ($db->inTransaction()) $db->rollBack();
            }
        }
    }
}

$amountFormatted = $order ? number_format((float)($order['amount_in_paise'] / 100), 2) : '0.00';
$displayUtr      = !empty($utr) ? $utr : ($order['utr'] ?? 'N/A');
$displayTxn      = $order['zapupi_txn_id'] ?? 'N/A';
$productTitle    = $order['title'] ?? 'Digital Product';
$resourceUrl     = !empty($order['resource_url']) ? $order['resource_url'] : '../my-purchases.html';
?>
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Payment Successful — ZapUPI</title>
  <link rel="stylesheet" href="assets/zapupi.css?v=1.0">
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
  <meta http-equiv="refresh" content="5;url=../my-purchases.html">
</head>
<body class="zap-body">

  <div class="zap-card zap-card-success">
    <div class="zap-icon-circle zap-icon-success">
      <i class="fa-solid fa-circle-check"></i>
    </div>

    <h1 class="zap-title">Payment Verified & Successful!</h1>
    <p class="zap-subtitle">Thank you for your payment. Your digital access to <strong><?= htmlspecialchars($productTitle) ?></strong> has been granted.</p>

    <div class="zap-details-box">
      <div class="zap-detail-row">
        <span>Order ID:</span>
        <strong><?= $order_id ?: 'N/A' ?></strong>
      </div>
      <div class="zap-detail-row">
        <span>Amount Paid:</span>
        <strong style="color: #166534; font-size: 1.1rem;">₹<?= $amountFormatted ?></strong>
      </div>
      <div class="zap-detail-row">
        <span>UTR / Ref No:</span>
        <strong><?= $displayUtr ?></strong>
      </div>
      <div class="zap-detail-row">
        <span>Transaction ID:</span>
        <strong><?= $displayTxn ?></strong>
      </div>
    </div>

    <p class="zap-redirect-text">
      <i class="fa-solid fa-spinner fa-spin"></i> Redirecting to your digital library in 5 seconds...
    </p>

    <div class="zap-btn-group">
      <a href="<?= htmlspecialchars($resourceUrl) ?>" target="_blank" class="zap-btn zap-btn-success">
        <i class="fa-solid fa-arrow-up-right-from-square"></i> Open Access Resource
      </a>
      <a href="../my-purchases.html" class="zap-btn zap-btn-outline">
        <i class="fa-solid fa-box"></i> View My Purchases
      </a>
    </div>
  </div>

</body>
</html>
