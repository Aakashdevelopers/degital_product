<?php
/**
 * ZapUPI Payment Timeout Page
 * File: zapupi/timeout.php
 */

require_once __DIR__ . '/config.php';

$order_id = htmlspecialchars(trim($_GET['order_id'] ?? ''), ENT_QUOTES, 'UTF-8');

$order = null;
if (!empty($order_id)) {
    try {
        $db   = zapDB();
        $stmt = $db->prepare("SELECT * FROM zap_orders WHERE order_id = ? LIMIT 1");
        $stmt->execute([$order_id]);
        $order = $stmt->fetch();
    } catch (Exception $e) {
        error_log('[Timeout Page Error] ' . $e->getMessage());
    }
}

$amountFormatted = $order ? number_format((float)$order['amount'], 2) : '0.00';
?>
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Payment Verification Pending — ZapUPI</title>
  <link rel="stylesheet" href="assets/zapupi.css?v=1.0">
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
</head>
<body class="zap-body">

  <div class="zap-card zap-card-timeout">
    <div class="zap-icon-circle zap-icon-timeout">
      <i class="fa-solid fa-hourglass-half fa-spin"></i>
    </div>

    <h1 class="zap-title">Payment Verification Timed Out</h1>
    <p class="zap-subtitle">
      We are still waiting for final payment status confirmation from ZapUPI or your bank.
    </p>

    <div class="zap-details-box">
      <div class="zap-detail-row">
        <span>Order ID:</span>
        <strong><?= $order_id ?: 'N/A' ?></strong>
      </div>
      <div class="zap-detail-row">
        <span>Amount:</span>
        <strong style="color: #b45309;">₹<?= $amountFormatted ?></strong>
      </div>
      <div class="zap-detail-row">
        <span>Status:</span>
        <strong style="color: #d97706;">Pending Verification</strong>
      </div>
    </div>

    <p style="font-size: 0.88rem; color: #64748b; margin-bottom: 1.5rem;">
      If you completed payment in your UPI app, please wait a moment for automatic confirmation or check your library.
    </p>

    <div class="zap-btn-group">
      <a href="../my-purchases.html" class="zap-btn zap-btn-warning">
        <i class="fa-solid fa-box"></i> Check My Library
      </a>
      <a href="../index.html" class="zap-btn zap-btn-outline">
        Return to Storefront
      </a>
    </div>
  </div>

</body>
</html>
