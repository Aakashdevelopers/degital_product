<?php
/**
 * ZapUPI Webhook Receiver Endpoint
 * File: zapupi/webhook.php
 */

require_once __DIR__ . '/config.php';

// Always return HTTP 200 JSON OK to webhook sender
function respondOk($msg = 'ok') {
    if (!headers_sent()) {
        http_response_code(200);
        header('Content-Type: application/json; charset=utf-8');
    }
    echo json_encode(['status' => 'ok', 'message' => $msg]);
    exit;
}

// Support browser GET check diagnostic
if ($_SERVER['REQUEST_METHOD'] === 'GET') {
    respondOk('ZapUPI Webhook Receiver Endpoint Active. Expects HTTP POST webhook notifications from ZapUPI.');
}

// ── Read Raw Input ──────────────────────────────────────
$raw  = file_get_contents('php://input');
$data = json_decode($raw, true);

if (!is_array($data)) {
    $data = $_POST ?: [];
}

// ── Validate & Sanitize Fields ──────────────────────────
$order_id = htmlspecialchars(trim($data['order_id'] ?? $data['orderId'] ?? ''), ENT_QUOTES, 'UTF-8');
$status   = htmlspecialchars(trim($data['status']   ?? $data['order_status'] ?? ''), ENT_QUOTES, 'UTF-8');
$txn_id   = htmlspecialchars(trim($data['txn_id']   ?? $data['transaction_id'] ?? ''), ENT_QUOTES, 'UTF-8');
$amount   = htmlspecialchars(trim($data['amount']   ?? ''), ENT_QUOTES, 'UTF-8');
$utr      = htmlspecialchars(trim($data['utr']      ?? $data['rrn'] ?? ''), ENT_QUOTES, 'UTF-8');
$env      = htmlspecialchars(trim($data['environment'] ?? ''), ENT_QUOTES, 'UTF-8');

if (empty($order_id)) {
    respondOk('Missing order_id ignored');
}

// ── Skip Test Webhooks in Production ────────────────────
if ($env === 'test' || strpos(strtolower($txn_id), 'dummy') === 0) {
    respondOk('Test environment webhook ignored for fulfillment');
}

// ── Double Confirm via Order Status API ─────────────────
$isConfirmedPaid = false;

$apiKey = getZapupiApiKey();
$ch = curl_init(ZAP_API_BASE . '/order-status');
$confirmPayload = http_build_query(['zap_key' => $apiKey, 'api_key' => $apiKey, 'order_id' => $order_id]);

curl_setopt_array($ch, [
    CURLOPT_POST           => true,
    CURLOPT_POSTFIELDS     => $confirmPayload,
    CURLOPT_HTTPHEADER     => [
        'Content-Type: application/x-www-form-urlencoded',
        'Accept: application/json',
        'User-Agent: Mozilla/5.0 (Windows NT 10.0; Win64; x64) ZapUPIModule/1.0'
    ],
    CURLOPT_RETURNTRANSFER => true,
    CURLOPT_TIMEOUT        => 15,
    CURLOPT_CONNECTTIMEOUT => 10,
    CURLOPT_SSL_VERIFYPEER => false,
    CURLOPT_SSL_VERIFYHOST => 0
]);
$confirmRaw = curl_exec($ch);
curl_close($ch);

$confirm = json_decode($confirmRaw, true);
$remoteData = ($confirm && isset($confirm['data']) && is_array($confirm['data'])) ? $confirm['data'] : $confirm;

$remoteStatus = strtoupper(trim($remoteData['status'] ?? $remoteData['order_status'] ?? $status));
$remoteEnv    = sanitizeString($remoteData['environment'] ?? $env);

if ($remoteEnv === 'test') {
    respondOk('Verified test environment status ignored');
}

if (in_array($remoteStatus, ['SUCCESS', 'COMPLETED', 'PAID', 'SUCCESSFUL'], true)) {
    $isConfirmedPaid = true;
    $targetStatus = 'Success';
} else {
    $targetStatus = (in_array($remoteStatus, ['FAILED', 'EXPIRED', 'CANCELLED'], true)) ? 'Failed' : 'pending';
}

// ── Update Database ─────────────────────────────────────
$db = zapDB();

try {
    // 1. Update zap_orders table
    try {
        $stmt = $db->prepare("
            UPDATE zap_orders
            SET status = ?, utr = ?, txn_id = ?, paid_at = IF(? = 'Success', NOW(), paid_at)
            WHERE order_id = ?
        ");
        $stmt->execute([$targetStatus, $utr, $txn_id, $targetStatus, $order_id]);
    } catch (Exception $e) {}

    // 2. Also update payment_orders & purchases tables if integrated
    if ($isConfirmedPaid) {
        $poStmt = $db->prepare("SELECT * FROM payment_orders WHERE order_id = ? LIMIT 1");
        $poStmt->execute([$order_id]);
        $po = $poStmt->fetch();

        if ($po) {
            $db->beginTransaction();

            $updPo = $db->prepare("UPDATE payment_orders SET status = 'completed', zapupi_txn_id = ?, utr = ? WHERE id = ?");
            $updPo->execute([$txn_id, $utr, $po['id']]);

            $insPur = $db->prepare("
                INSERT INTO purchases
                (user_id, firebase_uid, product_id, user_email, phone_number, purchase_type, status, price_snapshot_in_paise)
                VALUES
                (?, ?, ?, ?, ?, 'zapupi', 'granted', ?)
                ON DUPLICATE KEY UPDATE status = 'granted', purchase_type = 'zapupi', updated_at = CURRENT_TIMESTAMP
            ");
            $insPur->execute([
                $po['user_id'],
                $po['firebase_uid'],
                $po['product_id'],
                $po['customer_email'],
                $po['customer_phone'],
                $po['amount_in_paise']
            ]);

            $db->commit();
        }
    }
} catch (Exception $e) {
    if ($db->inTransaction()) {
        $db->rollBack();
    }
    error_log('[ZapUPI Webhook Error] Database update failed for ' . $order_id . ': ' . $e->getMessage());
}

respondOk('Webhook processed cleanly');
